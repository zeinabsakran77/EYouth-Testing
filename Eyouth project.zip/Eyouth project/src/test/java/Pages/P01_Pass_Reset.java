package Pages.Pass_Reset;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class P01_Pass_Reset {

    ChromeDriver Driver;
    private By Pass_ResetButton = By.className("forget");
    private By EmailLoc = By.id("email");
    private By GetPasswordLoc = By.className("btn-primary");

    public P01_Pass_Reset (ChromeDriver d)
    {
        this.Driver = d;
    }

    public void Click_ResetPassword ()
    {
        WebDriverWait wait = new WebDriverWait(Driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.className("forget")));
        Driver.findElement(Pass_ResetButton).click();
    }

    public void EnterEmail (String E)
    {
        Driver.findElement(EmailLoc).sendKeys(E);
    }

    public void Click_GetPassword ()
    {
        WebDriverWait wait = new WebDriverWait(Driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.className("btn-primary")));
        JavascriptExecutor js = (JavascriptExecutor) Driver;
        js.executeScript("arguments[0].click", Driver.findElement(GetPasswordLoc));

    }
}
