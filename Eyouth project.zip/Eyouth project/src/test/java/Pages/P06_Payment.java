package Pages;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class P06_Payment {
    ChromeDriver driver;
    WebDriverWait wait;

    private By continue_loc= By.cssSelector("button[class=\"btn w-100 btn-success process-btn\"]");
    private By fawry_loc= By.id("Fawry-Button");
    private By Visa_loc= By.id("Fawry-card");
    private By proceedBtn_loc =By.xpath("//span[text()=\"Proceed\"]/ancestor::button");

    private By DeleteAll_loc = By.xpath("//span[text()=\"Delete all\"]/ancestor::button");
    private By NoOf_courses_loc=By.cssSelector(".counterContainer small");
    private By delete_course_loc=By.xpath("//h5[text()=\"Business Development Management | إدارة تطوير الأعمال\"]" +
            "/parent::div/parent::div/div[3]/button");

    private By [] Courses_name_loc= {By.xpath("//h5[text()=\"Business Development Management | إدارة تطوير الأعمال\"]"),
            By.xpath("//h5[text()=\"Introduction in SMEs Banking | مقدمة في الخدمات المصرفية للمؤسسات الصغيرة والمتوسطة\"]")};
    private By [] Courses_price_loc={By.xpath("//h6[text()=\"300\"]"),
            By.xpath("//h6[text()=\"400\"]")};
    private By TotalPrice_loc=By.xpath("//span[contains(text(), \"700.00\")]");

    private By Before_logout_loc=By.xpath("//button[text()=\"zeinab7\"]");
    private By logout_loc= By.cssSelector("a[href=\"https://eyouthlearning.com/logout\"]");

    private  By empty_cart_loc=By.xpath("//span[contains(text(),\"empty\")]");
    private By delete_success_loc=By.className("btn-primary");


    // payment functionality
    private By cancel_loc = By.xpath("/html/body/div/main/div/div/div/section/div/div/div[2]/div/section/div[1]/div[2]/form/div[4]/button[1]");
    public P06_Payment(ChromeDriver driver) {
        this.driver = driver;
        this.wait=new WebDriverWait(driver, Duration.ofSeconds(30));

    }

    public void check_continue() {
        WebElement continueBtn = wait.until(ExpectedConditions.elementToBeClickable(continue_loc));
        boolean accept=continueBtn.isDisplayed();
        Assert.assertTrue(accept);
    }
    public void check_proceed() {
        WebElement proceedBtn = wait.until(ExpectedConditions.presenceOfElementLocated(proceedBtn_loc));
        boolean accept=proceedBtn.isDisplayed();
        boolean accept2=proceedBtn.isEnabled();
        SoftAssert soft=new SoftAssert();
        soft.assertTrue(accept);
        soft.assertFalse(accept2);
    }
    public void check_fawryCodeCB() {
        WebElement fawryBtn = wait.until(ExpectedConditions.elementToBeClickable(fawry_loc));
        boolean accept1=fawryBtn.isDisplayed();
        boolean accept2=fawryBtn.isEnabled();
        SoftAssert soft=new SoftAssert();
        soft.assertTrue(accept1);
        soft.assertTrue(accept2);
    }
    public void check_creditCardCB() {
        WebElement CreditBtn = wait.until(ExpectedConditions.elementToBeClickable(Visa_loc));
        boolean accept1=CreditBtn.isDisplayed();
        boolean accept2=CreditBtn.isEnabled();
        SoftAssert soft=new SoftAssert();
        soft.assertTrue(accept1);
        soft.assertTrue(accept2);
    }


    public void click_continue(){
         WebElement continueBtn = wait.until(ExpectedConditions.visibilityOfElementLocated(continue_loc));
         ((JavascriptExecutor) driver).executeScript("arguments[0].click();", continueBtn);
    }
     public void chose_fawry(){
         int attempts = 0;
         while (attempts < 3) {
             try {
                 WebElement fawryElement = wait.until(ExpectedConditions.elementToBeClickable(fawry_loc));
                 JavascriptExecutor js= (JavascriptExecutor) driver;
                 js.executeScript("arguments[0].click();",fawryElement);
                 //fawryElement.click();
                 break;
             } catch (StaleElementReferenceException | TimeoutException e) {
                 try {
                     Thread.sleep(1000); // wait a bit before retry
                 } catch (InterruptedException ie) {
                     Thread.currentThread().interrupt();
                 }
             }
             attempts++;
         }
    }
    public void chose_Card(){
        int attempts = 0;
        while (attempts < 3) {
            try {
                WebElement visaElement = wait.until(ExpectedConditions.visibilityOfElementLocated(Visa_loc));
                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", visaElement);                break;
            } catch (StaleElementReferenceException | TimeoutException e) {
                try {
                    Thread.sleep(1000); // wait a bit before retry
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                }
            }
            attempts++;
        }
    }
    public void click_proceed() {
         driver.findElement(proceedBtn_loc).click();
     }
    public void assertion_redirect(){
        wait.until(ExpectedConditions.urlContains("payment"));
        boolean a= driver.getCurrentUrl().contains("payment");
        Assert.assertTrue(a);
    }
    public void assert_proceed_checkout(){
       boolean accept= wait.until(ExpectedConditions.visibilityOfElementLocated(fawry_loc)).isDisplayed();
       Assert.assertTrue(accept);
    }

    public void assert_deletedCourse(){  //////error here
        boolean invisible = wait.until(ExpectedConditions.invisibilityOfElementLocated(Courses_name_loc[0]));
        Assert.assertTrue(invisible, "Course elements are still visible — expected none.");

//        boolean ele=driver.findElements(Courses_name_loc[0]).isEmpty();
//        Assert.assertTrue(ele);

    }
    public void check_btn_Delete(){
        try {
          WebElement element = wait.until(ExpectedConditions.presenceOfElementLocated(DeleteAll_loc));
          element.click();
        } catch (TimeoutException e) {
            System.out.println("No elements found, skipping click.");
        }
    }
    public void Delete_course(){
        for (int attempts = 0; attempts < 3; attempts++) {
            try {
                WebElement ele = wait.until(ExpectedConditions.elementToBeClickable(delete_course_loc));
                if (ele.isDisplayed()) {
                    ele.click();
                    break; //
                }
            } catch (Exception e) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                }
            }
        }

//        WebElement ele =wait.until(ExpectedConditions.elementToBeClickable(delete_course_loc));
//        Assert.assertTrue(ele.isDisplayed());
//        ele.click();
    }

    public void check_NoOf_Courses(String text){
        // Locate the <small> tag inside the counterContainer
        // Get the text
        boolean x= true;
        String counterText = wait.until(ExpectedConditions.visibilityOfElementLocated(NoOf_courses_loc)).getText();
        System.out.println(counterText);
        if(Objects.equals(counterText, text)){
            Assert.assertTrue(x);
        }else
            Assert.assertFalse(x);
    }
    public  void observe_course_contents(){
        SoftAssert soft= new SoftAssert();
        boolean Nele1=wait.until(ExpectedConditions.elementToBeClickable(Courses_name_loc[0])).isDisplayed();
        soft.assertTrue(Nele1);
        boolean Nele2=wait.until(ExpectedConditions.presenceOfElementLocated(Courses_name_loc[1])).isDisplayed();
        soft.assertTrue(Nele2);
        boolean Pele1=driver.findElement(Courses_price_loc[0]).isDisplayed();
        soft.assertTrue(Pele1);
        boolean Pele2=driver.findElement(Courses_price_loc[1]).isDisplayed();
        soft.assertTrue(Pele2);
        boolean total_price= driver.findElement(TotalPrice_loc).isDisplayed();
        soft.assertTrue(total_price);

        soft.assertAll();

    }
    public void assert_ExistanceCourse(){
        boolean Nele1=wait.until(ExpectedConditions.elementToBeClickable(Courses_name_loc[0])).isDisplayed();
        Assert.assertTrue(Nele1);
    }
    public void assert_empty_cart(){
        boolean accept=wait.until(ExpectedConditions.presenceOfElementLocated(empty_cart_loc)).isDisplayed();
        Assert.assertTrue(accept);
    }
    public void assert_DeletionAll(){
        boolean accept=wait.until(ExpectedConditions.presenceOfElementLocated(delete_success_loc)).isDisplayed();
        Assert.assertTrue(accept);
    }
    public void click_logout(){
       wait.until(ExpectedConditions.elementToBeClickable(Before_logout_loc)).click();
        driver.findElement(logout_loc).click();
    }
}
