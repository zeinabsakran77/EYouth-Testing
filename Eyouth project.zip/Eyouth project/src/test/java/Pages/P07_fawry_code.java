package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;

public class P07_fawry_code {


    ChromeDriver driver;
    WebDriverWait wait;
    private By genCode_loc=By.id("fawryCodeGen");
    private By assert_loc=By.xpath("//span[contains(text(), 'Fawry Outlets')]");


    // payment
    private By fawryIMG_loc = By.cssSelector("img.imgFawry");
    private By homePageBtn_loc = By.cssSelector(".btn-primary");

// fatma payment
    public void assert_fawry_img_displayed() {
        boolean imgVisible = wait.until(ExpectedConditions.visibilityOfElementLocated(fawryIMG_loc)).isDisplayed();
        assert imgVisible;
    }

    public void assert_home_page() {
        WebElement homeBtn  = wait.until(ExpectedConditions.elementToBeClickable(homePageBtn_loc));
        boolean accept=homeBtn.isDisplayed();
        Assert.assertTrue(accept);
    }

    public void  generate_code() {
        WebElement continueBtn = wait.until(ExpectedConditions.elementToBeClickable(genCode_loc));
        continueBtn.click();
    }
    public P07_fawry_code(ChromeDriver driver) {
        this.driver = driver;
        this.wait=new WebDriverWait(driver, Duration.ofSeconds(10));

    }

    public void assertion_fawry(){
        boolean x =wait.until(ExpectedConditions.visibilityOfElementLocated(assert_loc)).isDisplayed();
        Assert.assertTrue(x);
    }
}
