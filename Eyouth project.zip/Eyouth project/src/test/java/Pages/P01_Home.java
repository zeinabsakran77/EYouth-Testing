package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;

public class P01_Home {
    WebDriver driver;
    WebDriverWait wait;

    private By dropDown_loc= By.cssSelector("div.muirtl-wvevft-control");
    private By Lang_loc= By.cssSelector("input[type='text'][aria-autocomplete='list']");
    private By loginBtn_Loc= By.xpath("(//button[text()=\"Sign In\"])[2]");

    // for Download app button
    private By Download_loc = By.cssSelector("button[class=\"MuiButtonBase-root MuiFab-root " +
            "MuiFab-circular MuiFab-sizeLarge MuiFab-primary MuiSpeedDial-fab muirtl-1n0nj1r\"]");
    private By assert_home_loc= By.cssSelector("button[class=\"btn btn-outline-primary mx-1 navbar_btn_signup__z4Cok\"]");
    private By assert_AppleIcon_loc=By.cssSelector("svg[data-testid=\"AppleIcon\"]");
    private By assert_googleIcon_loc=By.cssSelector("svg[data-testid=\"AndroidIcon\"]");
    private By assert_hover_loc=By.cssSelector("button[aria-expanded=\"true\"]");

      // fatma code
    String cartURL = "https://apps.experience.eyouthlearning.com/payment?_gl=1*17bbxhg*_gcl_au*MjA5Mzk0Mjg5NS4xNzQ2MjEwODY5";

    public void openCart(){
        driver.navigate().to(cartURL);
    }

    public P01_Home(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));

    }

    public void click_dropdown(){
        WebElement dropdown = wait.until(ExpectedConditions.elementToBeClickable(dropDown_loc));
        dropdown.click();

    }
    public void send_input(String Language){
        WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(Lang_loc));
        input.sendKeys(Language);
        input.sendKeys(Keys.ENTER);

    }
    public void  click_loginBtn(){
        wait.until(ExpectedConditions.visibilityOfElementLocated(loginBtn_Loc)).click();

    }

    public void assert_home_page(){
       boolean accept= wait.until(ExpectedConditions.presenceOfElementLocated(assert_home_loc)).isDisplayed();
        Assert.assertTrue(accept);
    }
    public void check_download_button(){
        boolean accept= wait.until(ExpectedConditions.visibilityOfElementLocated(Download_loc)).isDisplayed();
        Assert.assertTrue(accept);
    }
    public void hover_download_btn(){
        Actions actions = new Actions(driver);
        actions.moveToElement(driver.findElement(Download_loc)).perform();

    }
    public void assert_appleIcon(){
        boolean accept= wait.until(ExpectedConditions.visibilityOfElementLocated(assert_AppleIcon_loc)).isDisplayed();
        Assert.assertTrue(accept);
    }
    public void assert_googleIcon(){
        boolean accept= wait.until(ExpectedConditions.visibilityOfElementLocated(assert_googleIcon_loc)).isDisplayed();
        Assert.assertTrue(accept);
    }
    public void assert_hover(){
        boolean accept= wait.until(ExpectedConditions.visibilityOfElementLocated(assert_hover_loc)).isDisplayed();
        Assert.assertTrue(accept);
    }

    // Hana
    public void AssertPass ()
    {
        boolean c = driver.getCurrentUrl().contains("eyouthlearning");
        Assert.assertTrue(c);
    }
    // fatma
    By confirmHome = By.xpath("/html/body/div/div/div[4]/div/div[1]/div");
    By allCoursesBtnLoc = By.xpath("/html/body/div/div/div[2]/div/div[1]/div/ul/div[1]/div/a");
    By freeCoursesCbLoc = By.xpath("//label[@for='Free']");
    By subscripedCourseLinkLoc = By.cssSelector("#coursesbody > div > div:nth-child(4) > div > div.MuiCardContent-root.muirtl-r1q4z4 > strong > p");
    By nonSubscripedCourseLinkLoc = By.xpath("//*[@id=\"coursesbody\"]/div/div[3]/div/div[2]");
    public By supscribedBtnLoc = By.xpath("/html/body/div/div/div[4]/div/div[1]/div[2]/div[3]/div/div[8]/div/div/button");
    By finishedCourse = By.cssSelector("div.AllCoursesAndFilteration_singleCourseCard__OI7R1:nth-child(2) > div:nth-child(1) > div:nth-child(2) > strong:nth-child(1) > p:nth-child(1)");


    public void navigateNonEnrolledCourse() {
        WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));

        wait.until(ExpectedConditions.visibilityOfElementLocated(confirmHome));

        wait.until(ExpectedConditions.elementToBeClickable(allCoursesBtnLoc)).click();
       wait.until(ExpectedConditions.elementToBeClickable(nonSubscripedCourseLinkLoc)).click();

        wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(supscribedBtnLoc));
    }

    public void navigateEnrolledCourse() {
        WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));

        WebElement element1 = wait.until(ExpectedConditions.elementToBeClickable(freeCoursesCbLoc));
        element1.click();

        WebElement element2 = wait.until(ExpectedConditions.elementToBeClickable(subscripedCourseLinkLoc));
        element2.click();

        WebElement element3 = wait.until(ExpectedConditions.elementToBeClickable(supscribedBtnLoc));
        element3.click();

    }

    public void navigateFinshedCourse() {
        WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));

        driver.get("https://eyouthlearning.com/all-courses?page=1&paid=false");

        wait.until(ExpectedConditions.elementToBeClickable(finishedCourse)).click();

        wait.until(ExpectedConditions.elementToBeClickable(supscribedBtnLoc)).click();
    }
}
