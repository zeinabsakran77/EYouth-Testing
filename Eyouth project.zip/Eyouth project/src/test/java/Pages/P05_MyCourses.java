package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;

public class P05_MyCourses {
    ChromeDriver driver;
    WebDriverWait wait;
    private By assert_loc_free=By.xpath("//h2[text()=\"Blockchain \"]");
    private By assert_paid_loc= By .xpath("//p[text()=\"Business Development Management \"]//ancestor::div[1]/parent::div/div[3]/div[2]/button");


    public P05_MyCourses(ChromeDriver driver) {

        this.driver = driver;
        this.wait=new WebDriverWait(driver, Duration.ofSeconds(10));
    }
    public void navigate_Dashboard(){

        driver.navigate().to("https://eyouthlearning.com/Mycourses");
    }
    public void assertion_free_true(){
        boolean b= wait.until(ExpectedConditions.visibilityOfElementLocated(assert_loc_free)).isDisplayed();
        Assert.assertTrue(b);
    }
    public void assertion_paid_false(){
        boolean b= driver.findElements(assert_paid_loc).isEmpty();
        Assert.assertTrue(b);
    }
}
