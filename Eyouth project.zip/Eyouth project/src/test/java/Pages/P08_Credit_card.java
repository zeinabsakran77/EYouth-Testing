package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;

public class P08_Credit_card {

ChromeDriver driver;
WebDriverWait wait;

private By CardNo_loc= By.id("cardNumber");
private By Name_loc= By.id("name");
private By EX_Month_loc=By.id("cardExpiryMonth");
private By EX_Year_loc=By.id("cardExpiryYear");
private By cvv_loc = By.id("cvv");
private By submit_loc= By.cssSelector("button[type=\"submit\"]");

private By success_loc=By.id("customerAuthFormAutoSubmit:validAuthentication");
private By enter_code_loc=By.id("customerAuthFormAutoSubmit:athenticateEntry");

private By goBack_loc = By.cssSelector(".mx-1");
private By continue_loc = By.cssSelector("button.btn:nth-child(2)");
private By otp_loc=By.xpath("//label[text()=\"You took too long to enter your password. Try resending the code\"]");
String credit_url= "https://apps.experience.eyouthlearning.com/payment/fawry-card";

// fatma payment

    public void check_goBack() {
        WebElement backBtn = wait.until(ExpectedConditions.elementToBeClickable(goBack_loc));
        backBtn.isDisplayed();
        boolean accept =backBtn.isDisplayed();
        Assert.assertTrue(accept);
    }

    public void check_continue(boolean X) {
        WebElement continueBtn = wait.until(ExpectedConditions.elementToBeClickable(continue_loc));
        boolean accept =continueBtn.isDisplayed();
        if(X==true){
            continueBtn.click();
        }
        Assert.assertTrue(accept);
    }

    public void clear_card_data() {
        driver.findElement(Name_loc).clear();
        driver.findElement(CardNo_loc).clear();
        driver.findElement(EX_Month_loc).clear();
        driver.findElement(EX_Year_loc).clear();
        driver.findElement(cvv_loc).clear();
    }
public P08_Credit_card(ChromeDriver driver) {
    this.driver = driver;
    this.wait = new WebDriverWait(driver, Duration.ofSeconds(30));

}

public void Enter_CardNo(String card_No){
    wait.until(ExpectedConditions.presenceOfElementLocated(CardNo_loc)).sendKeys(card_No);
}
public void Enter_Name(String name) {
    driver.findElement(Name_loc).sendKeys(name);
}
public void Enter_EX_month(String month){
        driver.findElement(EX_Month_loc).sendKeys(month);
}
public void Enter_Ex_year(String year){
        driver.findElement(EX_Year_loc).sendKeys(year);
}
public void Enter_cvv(String cvv){
        driver.findElement(cvv_loc).sendKeys(cvv);
}
public void Click_submit(){
    driver.findElement(submit_loc).click();
}
public void  assertion_error(){
    boolean a= driver.getCurrentUrl().contains("https://apps.experience.eyouthlearning.com/payment/fawry-card");
    Assert.assertTrue(a);
}
public void assertion_success(boolean X,String code){
    WebElement Ele=wait.until(ExpectedConditions.visibilityOfElementLocated(success_loc));
    WebElement Ele2=wait.until(ExpectedConditions.visibilityOfElementLocated(enter_code_loc));
    if(X==false) {
        boolean accept = Ele.isDisplayed();
        Assert.assertTrue(accept);
    }
    if(X==true)
    {
        Ele2.sendKeys(code);
        Ele.click();

    }
}
public void assertion_failed(){
    WebElement Ele=wait.until(ExpectedConditions.visibilityOfElementLocated(success_loc));
    boolean accept=Ele.isDisplayed();
    Assert.assertFalse(accept);
}
public void otp_assertion(){
    WebElement Ele=wait.until(ExpectedConditions.visibilityOfElementLocated(otp_loc));
    boolean accept=Ele.isDisplayed();
    Assert.assertTrue(accept);
}
public void assert_credit_url(){
    Assert.assertTrue(driver.getCurrentUrl().equals(credit_url));

}
}
