package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;

public class P09_Course_Details {

WebDriver driver;
WebDriverWait wait;
private By Cart_loc=By.xpath("//button[ text()=\"Add to Cart\"]");
private By start_course_loc= By.xpath("//a[text()=\"Start course\"]");

public P09_Course_Details(WebDriver driver) {
    this.driver = driver;
    this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
}

public void assert_current_url(){

    Assert.assertTrue(driver.getCurrentUrl().contains("details"));
}
public void assert_add2Cart(char C,boolean click){
    if (C=='p'){
        WebElement add2Cart_ele = wait.until(ExpectedConditions.elementToBeClickable(Cart_loc));
        boolean cart_btn =add2Cart_ele.isDisplayed();
        Assert.assertTrue(cart_btn);
        if(click==true){
            add2Cart_ele.click();
        }

    }
    if(C=='f'){
        boolean x=driver.findElements(Cart_loc).isEmpty();
        Assert.assertFalse(x);
    }

}
public void assert_duplicate_prevention(){
    int attempts = 0;
    while (attempts < 3) {
        try {
            WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(start_course_loc));
            boolean accept= element.isDisplayed();
            Assert.assertEquals(accept,true);

            break; // if successful, exit loop
        } catch (StaleElementReferenceException e) {
            try {
                Thread.sleep(1000); // 1 second
            } catch (InterruptedException s) {
                s.printStackTrace(); // Or handle it more gracefully
            }        }
        attempts++;
    }
}
// fatma
public By startCourseBtn = By.cssSelector("a.btn");
    public By courseBanner = By.cssSelector(".next-btn");
    public By finalQuizDl = By.cssSelector("#courseHome-outline > li:nth-child(4) > div:nth-child(1) > div:nth-child(1) > span:nth-child(2) > button:nth-child(1) > span:nth-child(1) > svg:nth-child(1)");
    public By finalQuizUrl = By.cssSelector(".text-break > span:nth-child(1) > a:nth-child(1)");
    public By questionSubmitBtn = By.cssSelector(".submit");
    public By ProgressBtn = By.cssSelector("a.nav-item:nth-child(2)");
    public By certificateStatus = By.cssSelector(".pgn__card-section");
    public By nextBtn = By.cssSelector(".next-btn");
    public By progressPercent = By.cssSelector(".donut-chart-number");
    public By certificateImg = By.cssSelector(".certificate-wrapper > header:nth-child(1) > img:nth-child(1)");

    public boolean userCanOpenCourseContent() {
        WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));

        wait.until(ExpectedConditions.elementToBeClickable(startCourseBtn));
        driver.findElement(startCourseBtn).click();

        wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(courseBanner));
        if(driver.findElement(courseBanner).isDisplayed())
            return true;
        else
            return false;
    }

    public boolean userCanOpenQuiz() {
        WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20));

        wait.until(ExpectedConditions.elementToBeClickable(finalQuizDl));
        driver.findElement(finalQuizDl).click();

        Actions builder = new Actions(driver);
        builder.scrollByAmount(0, 50).build().perform();

        wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(finalQuizUrl));
        driver.findElement(finalQuizUrl).click();

        wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(courseBanner));
        if(driver.findElement(courseBanner).isDisplayed())
            return true;
        else
            return false;
    }

    public boolean userCanSubmitNonAnswered() {
        WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20));

        Actions builder = new Actions(driver);
        builder.scrollByAmount(0, 50).build().perform();

        try {
            driver.findElement(questionSubmitBtn);
            return true; // Element is found
        } catch (Exception e) {
            return false; // Element does not exist
        }
    }

    public boolean noCourseNoCertificate() {
        WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));

        wait.until(ExpectedConditions.elementToBeClickable(ProgressBtn)).click();

        wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(certificateStatus));
        return driver.findElement(certificateStatus).getText() != "Download Certificate";
    }

    public void skipCourseContent() {
        WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));

        wait.until(ExpectedConditions.elementToBeClickable(startCourseBtn)).click();

        wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(courseBanner));

        for(int i = 0; i < 5 ; i++) {
            wait.until(ExpectedConditions.elementToBeClickable(nextBtn)).click();
        }

        wait.until(ExpectedConditions.elementToBeClickable(ProgressBtn)).click();

        wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(progressPercent));
    }

    public void availableCertificate() {
        WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));

        wait.until(ExpectedConditions.elementToBeClickable(startCourseBtn)).click();
    }

}
