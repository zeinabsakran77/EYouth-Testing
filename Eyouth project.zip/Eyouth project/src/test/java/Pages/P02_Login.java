package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;

public class P02_Login
{
    WebDriver driver;
    WebDriverWait wait;
    private By  userName_loc=By.id("username");
    private By pass_loc =By.id("password");
    private By Sign_Btn_loc =By.xpath("(//button[text()=\"Sign In\"])[2]");

    private By LoginBtnLoc = By.className("signup--btn");
    private By  assert_Loc = By.xpath("(//p[text()=\"zeinab7\"])[2]");

    public P02_Login(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));

    }
    public void Enter_userName(String UN){
        wait.until(ExpectedConditions.visibilityOfElementLocated(userName_loc)).sendKeys(UN);

    }
    public void ClickLogin ()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.className("signup--btn")));
        driver.findElement(LoginBtnLoc).click();
    }
    public void Enter_password(String pass){
        wait.until(ExpectedConditions.visibilityOfElementLocated(pass_loc)).sendKeys(pass);

    }
    public void Click_Signin(){
        wait.until(ExpectedConditions.presenceOfElementLocated(Sign_Btn_loc)).click();
    }
    public void assert_login(){
        WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(assert_Loc));
        Assert.assertTrue(element.isDisplayed());
    }
}

