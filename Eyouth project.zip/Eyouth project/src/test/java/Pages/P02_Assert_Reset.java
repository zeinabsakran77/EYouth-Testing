package Pages.Pass_Reset;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;

public class P02_Assert_Reset {

    ChromeDriver Driver;
    private By MessageLoc = By.className("MuiAlert-message");

    public P02_Assert_Reset (ChromeDriver d)
    {
        this.Driver = d;
    }

    public void AssertSent ()
    {
        WebDriverWait wait = new WebDriverWait(Driver, Duration.ofSeconds(2));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.className("MuiAlert-message")));
        boolean x = Driver.findElements(MessageLoc).isEmpty();
        Assert.assertFalse(x);
    }

    public void Assert_NSent ()
    {
        boolean y = Driver.findElements(MessageLoc).isEmpty();
        Assert.assertTrue(y);
    }
}
