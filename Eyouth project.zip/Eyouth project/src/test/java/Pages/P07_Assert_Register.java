package Pages;

import Features.*;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;

public class P07_Assert_Register {
    ChromeDriver driver;
    private By Assertion = By.className("register-continue-button");
    private By assertion_name_error=By.xpath("//p[text()=\"The name must be letters only\"]");
    private By assertion_name_empty=By.xpath("//p[text()=\"Name is Required\"]");

    WebDriverWait wait;

    public P07_Assert_Register(ChromeDriver d) {
        this.driver = d;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));

    }

    public void AssertReg() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.className("register-continue-button")));
        boolean x = driver.findElements(Assertion).isEmpty();
        Assert.assertFalse(x);
    }

    // Error assertion methods for each field
    public void AssertNameError(int x) {
        if(x==0){
            boolean assertion = wait.until(ExpectedConditions.visibilityOfElementLocated(assertion_name_empty)).isDisplayed();
            Assert.assertTrue(assertion);
        }
        if(x==1) {
            boolean assertion = wait.until(ExpectedConditions.visibilityOfElementLocated(assertion_name_error)).isDisplayed();
            Assert.assertTrue(assertion);
        }
    }

    public void AssertUsernameError(String expectedError) {
        String actualError = driver.findElement(By.id("username-helper-text")).getText();
        Assert.assertEquals(actualError, expectedError);
    }

    public void AssertCountryError(String expectedError) {
        String actualError = driver.findElement(By.className("MuiFormHelperText-root")).getText();
        Assert.assertEquals(actualError, expectedError);
    }

    public void AssertGenderError(String expectedError) {
        String actualError = driver.findElement(By.className("MuiFormHelperText-root")).getText();
        Assert.assertEquals(actualError, expectedError);
    }

    public void AssertGovernmentError(String expectedError) {
        String actualError = driver.findElement(By.className("MuiFormHelperText-root")).getText();
        Assert.assertEquals(actualError, expectedError);
    }

    public void AssertEmailError(String expectedError,int x) {
        if(x==0) {
            String actualError = driver.findElement(By.id("email-helper-text")).getText();

            Assert.assertTrue(actualError.contains(expectedError));
        }
        if(x==1){
            String actualError = wait.until(ExpectedConditions.presenceOfElementLocated(By.className("MuiAlert-message"))).getText();
            Assert.assertTrue(actualError.contains(expectedError));
        }
    }

    public void AssertPhoneError(String expectedError) {
        String actualError = driver.findElement(By.id("phone_number-helper-text")).getText();
        Assert.assertEquals(actualError, expectedError);
    }

    public void AssertPasswordError(String expectedError) {
        String actualError = driver.findElement(By.id("password-helper-text")).getText();
        Assert.assertEquals(actualError, expectedError);
    }

    public void AssertConfirmPasswordError(String expectedError) {
        String actualError = driver.findElement(By.id("confirmPassword-helper-text")).getText();
        Assert.assertEquals(actualError, expectedError);
    }

    public void AssertTermsError(String expectedError) {
        String actualError = driver.findElement(By.className("signup_errorText__IvnT-")).getText();
        Assert.assertEquals(actualError, expectedError);
    }
}

