package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;

public class P03_Home_logged_User {
    ChromeDriver driver;
    WebDriverWait wait;

    private By hover_loc=By.cssSelector("a[href=\"/all-courses\"]");
    private By All_courses_loc= By.xpath("//a[text()=\"All courses\"]");
    private By Cart_loc=By.cssSelector("a[href=\"https://apps.experience.eyouthlearning.com/payment\"]");

    private By CartIcon = By.cssSelector("p[class=\"p-0 m-0\"]");


    public void AssertPass ()
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(CartIcon));
        boolean x = driver.findElements(CartIcon).isEmpty();
        Assert.assertFalse(x);
    }
    public void AssertFail ()
    {
        boolean y = driver.findElements(CartIcon).isEmpty();
        Assert.assertTrue(y);
    }

    public P03_Home_logged_User(ChromeDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }
    public void hover(){
        Actions act = new Actions(driver);
        act.moveToElement(wait.until(ExpectedConditions.elementToBeClickable(hover_loc))).perform();
    }
    public void click_allCourses(){
        wait.until(ExpectedConditions.elementToBeClickable(All_courses_loc)).click();
    }
    public void click_CartBtn(){
        wait.until(ExpectedConditions.elementToBeClickable(Cart_loc)).click();
    }
    public void navigate_home(){
        driver.navigate().to("https://eyouthlearning.com/");
    }

}
