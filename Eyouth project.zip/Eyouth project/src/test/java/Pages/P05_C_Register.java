package Pages;

import Features.*;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;
public class P05_C_Register {

    ChromeDriver driver;
    private By RegisterIcon = By.className("ico-register");

    public P05_C_Register(ChromeDriver d) {
        this.driver = d;
    }

    public void ClickRegister() {
        driver.findElement(RegisterIcon).click();
    }

}
