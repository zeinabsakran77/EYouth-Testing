package Pages;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;

public class P04_all_courses
{
    ChromeDriver driver;
    WebDriverWait wait;

    private By filter_free_loc=By.xpath("//label[@for='Free']");
    private By filter_paid_loc=By.xpath("//label[@for='Paid']");

    private By Enroll_free_loc=By.xpath("//p[text()=\"Blockchain \"]//ancestor::div[1]/parent::div/div[3]/div[2]/button");
    private By Enroll_paid_loc= By .xpath("//p[text()=\"Business Development Management \"]//ancestor::div[1]/parent::div/div[3]/div[2]/button");
     private By Status_loc=By.xpath("//p[text()=\"Blockchain \"]" +
             "//ancestor::div[1]/parent::div/div[3]/div[2]/button[text()=\"Enrolled\"]");
     private By add2Cart_loc =By.xpath("//p[text()=\"Business Development Management \"]" +
             "//ancestor::div[1]/parent::div/div[3]/div[2]/button[text()=\"Cart\"]");

     private By [] click_Paidcourse_loc={ By.cssSelector("div[title=\"course-v1:Business_and_Management+BDMXZ6IB2024+BDM6BRZN2024\"]"),
         By.cssSelector("[title=\"course-v1:Banking+IISBBPPGL2024+IISBFAW6F2024\"]")};
     private By click_Freecourse_loc = By.xpath("//p[text()=\"Legalities level 1 \"]");

     public P04_all_courses(ChromeDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));

    }
    public void filter_free(){
       wait.until(ExpectedConditions.elementToBeClickable(filter_free_loc)).click();
    }
    public void filter_paid(){
        wait.until(ExpectedConditions.elementToBeClickable(filter_paid_loc)).click();
    }

    public void Enroll_free()  {
        int attempts = 0;
        while (attempts < 3) {
            try {
                WebElement element =  wait.until(ExpectedConditions.elementToBeClickable(Enroll_free_loc));
                element.click();
                break; // if successful, exit loop
            } catch (StaleElementReferenceException e) {
                try {
                    Thread.sleep(1000); // 1 second
                } catch (InterruptedException a) {
                    a.printStackTrace(); // Or handle it more gracefully
                }            }
            attempts++;
        }}
    public void Enroll_paid(){
        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(Enroll_paid_loc));
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
    }
    public void check_Status_Btn(){
        boolean IsEnroll= wait.until(ExpectedConditions.visibilityOfElementLocated(Status_loc)).isDisplayed();
        Assert.assertTrue(IsEnroll);
    }
    public void check_add2Cart_btn(){
        boolean add2Cart =driver.findElements(add2Cart_loc).isEmpty();
        Assert.assertFalse(add2Cart);
    }
    public void clickOn_Paidcourse(int index){
            int attempts = 0;
            while (attempts < 3) {
                try {
                    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(click_Paidcourse_loc[index]));
                    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
                    break; // clicked successfully
                } catch (StaleElementReferenceException | TimeoutException | ElementClickInterceptedException e) {
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                    }
                }
                attempts++;
        }
    }
    public void clickOn_Freecourse(){
        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(click_Freecourse_loc));
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
    }
    public void assertion_redirect(){
        boolean a= driver.getCurrentUrl().contains("payment");
        Assert.assertFalse(a);
}
    public void navigate_All_PaidCourses(){
         driver.navigate().to("https://eyouthlearning.com/all-courses?page=1&paid=true");
    }

}
