package Pages.Ratings;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;

public class P02_GoToCourse {

    ChromeDriver Driver;
    private By CartIcon = By.cssSelector("p[class=\"p-0 m-0\"]");
    By OpenMyCourses = By.xpath("//p[.=\"HanaYassin\"]");
    By MyCoursesLoc = By.cssSelector("a[href=\"/Mycourses\"]");
    By Courses = By.cssSelector("a[href=\"/all-courses\"]");

    public P02_GoToCourse(ChromeDriver d)
    {
        this.Driver = d;
    }
    public void AssertPass ()
    {
        WebDriverWait wait = new WebDriverWait(Driver, Duration.ofSeconds(20));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("p[class=\"p-0 m-0\"]")));
        boolean x = Driver.findElements(CartIcon).isEmpty();
        Assert.assertFalse(x);
    }
    public void Courses ()
    {
        WebDriverWait wait = new WebDriverWait(Driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.presenceOfElementLocated(Courses));
        Driver.findElement(Courses).click();
    }

    public void OpenMyCourses ()
    {
        Driver.findElement(OpenMyCourses).click();
    }
    public void MyCoursesLoc ()
    {
        WebDriverWait wait = new WebDriverWait(Driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("a[href=\"/Mycourses\"]")));
        Driver.findElement(MyCoursesLoc).click();
    }

    public void assert_notlogged_user(){
       boolean accept= Driver.findElements(OpenMyCourses).isEmpty();
       Assert.assertTrue(accept);
    }
    //Alternative scenario

//    public void MyCourses ()
//    {
//        WebDriverWait wait = new WebDriverWait(Driver, Duration.ofSeconds(10));
//        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//p[.=\"HanaYassin\"]")));
//        WebElement ele = Driver.findElement(OpenMyCourses);
//        Select sel = new Select(ele);
//        sel.deselectByVisibleText("My Courses");
//    }


}
