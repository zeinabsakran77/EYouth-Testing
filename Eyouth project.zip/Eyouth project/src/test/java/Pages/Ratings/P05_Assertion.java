package Pages.Ratings;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;

public class P05_Assertion {
    ChromeDriver Driver;
    String FirstNumber;
    String UpdatedNumber;
    By CheckNum = By.className("CourseDetailsPart_line__fUZZw");
    By Assertion = By.className("courseDetails_courseTitle__tmIRd");
    By Add_ReviewLoc = By.xpath("//button[.=\"أضف تقييمك\"]");

    public P05_Assertion (ChromeDriver d)
    {
        this.Driver = d;
    }

    public void AssertReviewAdded ()
    {
        WebDriverWait wait = new WebDriverWait(Driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.presenceOfElementLocated(Assertion));
        boolean c = Driver.getCurrentUrl().contains("details");
        Assert.assertTrue(c);
    }
    public void AssertReview_NAdded ()
    {
        boolean c = Driver.getCurrentUrl().contains("details");
        Assert.assertFalse(c);
    }
    public void CheckNum1 () throws InterruptedException
    {
        WebDriverWait wait = new WebDriverWait(Driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.presenceOfElementLocated(Assertion));
        FirstNumber = Driver.findElement(CheckNum).getText();
        Driver.navigate().back();
    }

    public void CheckNum2 ()
    {
        UpdatedNumber = Driver.findElement(CheckNum).getText();

        assert UpdatedNumber != FirstNumber : "The number didn't increase";
    }

    public void AssertNFound ()
    {
        WebDriverWait wait = new WebDriverWait(Driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.presenceOfElementLocated(Assertion));
        boolean x = Driver.findElements(Add_ReviewLoc).isEmpty();
        Assert.assertTrue(x);
    }


}
