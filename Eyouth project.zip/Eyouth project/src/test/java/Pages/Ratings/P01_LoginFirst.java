package Pages.Ratings;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class P01_LoginFirst {

    ChromeDriver Driver;
    private By userNameLoc = By.id("username");
    private By passwordLoc = By.id("password");
    private By LoginBtnLoc = By.className("signup--btn");
    private By Language = By.className("muirtl-19bb58m");

    public P01_LoginFirst(ChromeDriver d)
    {
        this.Driver = d;
    }

    public void GoToHome ()
    {
        Driver.get("https://eyouthlearning.com/");
    }

    public void EnterUserName (String UN)
    {
        WebDriverWait wait = new WebDriverWait(Driver,Duration.ofSeconds(10));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("username")));
        Driver.findElement(userNameLoc).sendKeys(UN);
    }

    public void EnterPassword (String PW)
    {
        WebDriverWait wait = new WebDriverWait(Driver,Duration.ofSeconds(10));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("password")));
        Driver.findElement(passwordLoc).sendKeys(PW);
    }

    public void ClickLogin ()
    {
        WebDriverWait wait = new WebDriverWait(Driver,Duration.ofSeconds(10));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.className("signup--btn")));
        Driver.findElement(LoginBtnLoc).click();
    }
}
