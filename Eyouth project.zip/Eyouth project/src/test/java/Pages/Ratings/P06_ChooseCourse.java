package Pages.Ratings;

import org.checkerframework.checker.units.qual.C;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;

public class P06_ChooseCourse {

    ChromeDriver Driver;
    By ChooseFree = By.id("Free");
    By A_Course = By.className("muirtl-1qfy8rw");


    public P06_ChooseCourse (ChromeDriver d)
    {
        this.Driver = d;
    }

    public void ChooseFree ()
    {
        WebDriverWait wait = new WebDriverWait(Driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.presenceOfElementLocated(ChooseFree));
        Driver.findElement(ChooseFree).click();
    }
    public void A_Course ()
    {
        WebDriverWait wait = new WebDriverWait(Driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.presenceOfElementLocated(A_Course));
        Driver.findElement(A_Course).click();
    }

}
