package Pages.Ratings;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class P04_AddReview {

    ChromeDriver Driver;
    By Title_Loc = By.id("title");
    By OneStarLoc = By.xpath("//span[.=\"سئ جداَ\"]");
    By TwoStarsLoc = By.xpath("//span[.=\"سئ\"]");
    By ThreeStarsLoc = By.xpath("//span[.=\"جيد\"]");
    By FourStarsLoc = By.xpath("//span[.=\"جيد جداَ\"]");
    By FiveStarsLoc = By.xpath("//span[.=\"ممتاز\"]");
    By SubjectLoc = By.id("topic");
    By Add_Loc = By.cssSelector("button[type=\"submit\"]");

    public P04_AddReview (ChromeDriver d)
    {
        this.Driver = d;
    }

    public void JustWait ()
    {
        WebDriverWait wait = new WebDriverWait(Driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.presenceOfElementLocated(Title_Loc));
    }
    public void Add_Title (String T)
    {
        Driver.findElement(Title_Loc).sendKeys(T);
    }
    public void Choose1Star ()
    {
        Driver.findElement(OneStarLoc).click();
    }
    public void Choose2Stars ()
    {

        Driver.findElement(TwoStarsLoc).click();
    }
    public void Choose3Stars ()
    {
        Driver.findElement(ThreeStarsLoc).click();
    }
    public void Choose4Stars ()
    {
        Driver.findElement(FourStarsLoc).click();
    }
    public void Choose5Stars ()
    {
        Driver.findElement(FiveStarsLoc).click();
    }
    public void Add_Subject (String S)
    {
        Driver.findElement(SubjectLoc).sendKeys(S);
    }
    public void Click_Submit ()
    {
       WebElement Ele =Driver.findElement(Add_Loc);
        ((JavascriptExecutor) Driver).executeScript("arguments[0].click();",Ele);

    }
}
