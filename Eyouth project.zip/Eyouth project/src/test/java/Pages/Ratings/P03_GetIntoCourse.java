package Pages.Ratings;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class P03_GetIntoCourse {

    ChromeDriver Driver;
    By Add_ReviewLoc = By.xpath("//button[.=\"أضف تقييمك\"]");
    By GoToCourse = By.className("mycourseImage");


    public P03_GetIntoCourse (ChromeDriver d)
    {
        this.Driver = d;
    }
    public void Add_ReviewLoc ()       // To write review
    {
        WebDriverWait wait = new WebDriverWait(Driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[.=\"أضف تقييمك\"]")));
        Driver.findElement(Add_ReviewLoc).click();
    }
    public void GoToCourse ()       // To Check The number  , For TC_08
    {

        WebDriverWait wait = new WebDriverWait(Driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.className("mycourseImage")));
        Driver.findElement(GoToCourse).click();
    }

}
