package Pages;

import Features.*;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class P06_Register {
    ChromeDriver driver;
    WebDriverWait wait;

    private By nameField = By.id("name");
    private By usernameField = By.id("username");
    private By countryDropdown = By.id("country-select"); // MUI dropdown
    private By genderDropdown = By.id("gender-select");   // MUI dropdown
    private By governmentDropdown = By.id("government-select"); // MUI dropdown
    private By emailField = By.id("email");
    private By phoneField = By.id("phone_number");
    private By passwordField = By.id("password");
    private By confirmPasswordField = By.id("confirmPassword");
    private By termsCheckbox = By.id("accept"); // Checkbox input for terms
    private By registerButton = By.cssSelector("button.signup--btn"); // Submit button

    public P06_Register(ChromeDriver d) {
        this.driver = d;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));

    }

    public void enterName(String name) {
       // driver.findElement(nameField).clear();
       wait.until(ExpectedConditions.visibilityOfElementLocated(nameField)).sendKeys(name);
    }

    public void enterUsername(String username) {
        driver.findElement(usernameField).clear();
        driver.findElement(usernameField).sendKeys(username);
    }

    // MUI dropdowns: click, then select option by visible text
    public void selectCountry(String country) {
        driver.findElement(countryDropdown).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[contains(text(),'" + country + "')]"))).click();
    }

    public void selectGender(String gender) {
        driver.findElement(genderDropdown).click();
       WebElement Ele=wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[contains(text(),'" + gender + "')]")));
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();",Ele);

    }

    public void selectGovernment(String government) {
        driver.findElement(governmentDropdown).click();
        WebElement Ele=wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[contains(text(),'" + government + "')]")));
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();",Ele);

    }

    public void enterEmail(String email) {
        driver.findElement(emailField).clear();
        driver.findElement(emailField).sendKeys(email);
    }

    public void enterPhone(String phone) {
        driver.findElement(phoneField).clear();
        driver.findElement(phoneField).sendKeys(phone);
    }

    public void enterPassword(String password) {
        driver.findElement(passwordField).clear();
        driver.findElement(passwordField).sendKeys(password);
    }

    public void enterConfirmPassword(String confirmPassword) {
        driver.findElement(confirmPasswordField).clear();
        driver.findElement(confirmPasswordField).sendKeys(confirmPassword);
    }

    public void acceptTerms() {
        WebElement checkbox = driver.findElement(termsCheckbox);
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block: 'center'});", checkbox);
        ((JavascriptExecutor) driver).executeScript("window.scrollBy(0, 200);");

        if (checkbox.isEnabled()) {
            checkbox.click();
        } else {
            System.out.println("Still not visible after scroll.");
        }

    }

    public void clickRegisterButton() {
        ((JavascriptExecutor) driver).executeScript("window.scrollBy(0, 200);");
      WebElement Ele = wait.until(ExpectedConditions.elementToBeClickable(registerButton));
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();",Ele);

    }
}
