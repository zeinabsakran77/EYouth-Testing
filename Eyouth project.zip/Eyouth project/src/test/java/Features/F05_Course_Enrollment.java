package Features;

import Pages.*;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class F05_Course_Enrollment {

    ChromeDriver driver;
    P01_Home PH;
    P02_Login PL;
    P03_Home_logged_User PHL;
    P04_all_courses PC;
    P05_MyCourses MC;
    P06_Payment PP;
    P07_fawry_code FC;
    P08_Credit_card Cc;
    P09_Course_Details CD;

    @BeforeMethod
    void setUp() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        PH=new P01_Home(driver);
        PL=new P02_Login(driver);
        PHL=new P03_Home_logged_User(driver);
        PC= new P04_all_courses(driver);
        MC= new P05_MyCourses(driver);
        PP= new P06_Payment(driver);
        FC=new P07_fawry_code(driver);
        Cc =new P08_Credit_card(driver);
        CD=new P09_Course_Details(driver);
        driver.get("https://eyouthlearning.com/");

        // preRequest
        // 1--> change language , enter click immediately
        PH.click_dropdown();
        PH.send_input("English");

        // 2--> login
        PH.click_loginBtn();
        PL.Enter_userName("zeinab7");
        PL.Enter_password("88888888");
        PL.Click_Signin();
        PL.assert_login();
    }
    @Test
    void TC_01() {
        // step 1 --> open courses page (Hover and click "all courses")
        PHL.hover();
        PHL.click_allCourses();
        // step 2 --> filter courses to be free
        PC.filter_free();
        //step 3 --> choose "BlockChain" & click Enroll
        PC.Enroll_free();
        // step 4 --> assertion: course will be added successfully without redirect to payment gateway
       PC.assertion_redirect();

    }
    @Test
    void TC_02(){
        // step 1 --> open courses page (Hover and click "all courses")
        PHL.hover();
        PHL.click_allCourses();
        // step 2 --> filter courses to be free
        PC.filter_free();
        //step 3 --> choose "BlockChain" & click Enroll
        PC.Enroll_free();
        // step 4 -->  navigate to courses page
        driver.navigate().to("https://eyouthlearning.com/all-courses");
        PC.filter_free();
        //step 5 --> check that website updates status of Enroll Button for that course
        PC.check_Status_Btn();


    }
    @Test
    void TC_03(){
        // step 1 --> open courses page (Hover and click "all courses")
        PHL.hover();
        PHL.click_allCourses();
        // step 2 --> filter courses to be free
        PC.filter_free();
        //step 3 & 4  --> choose "BlockChain" & click Enroll
        PC.Enroll_free();
        // Step 5 -->  assertion: check user dashboard
        MC.navigate_Dashboard();
        MC.assertion_free_true();

    }
    @Test
    void TC_04(){
        // step 1 --> open courses page (Hover and click "all courses")
        PHL.hover();
        PHL.click_allCourses();
        // step 2 --> filter courses to be paid
        PC.filter_paid();
        //step 3 --> choose "Business Development Management " & click Enroll
        PC.Enroll_paid();
        // step --> assertion (redirect user to payment gateway)
        PP.assertion_redirect();
    }
    @Test
    void TC_05(){
        // step 1 --> open courses page (Hover and click "all courses")
        PHL.hover();
        PHL.click_allCourses();
        // step 2 --> filter courses to be paid
        PC.filter_paid();
        //step 3&4 --> choose "Business Development Management " & click Enroll
        PC.Enroll_paid();
        // step 5 --> proceed to payment  ( fawry)
        PP.click_continue();
        // step 6 --> Enter payment details
        PP.chose_fawry();
        PP.click_proceed();
        // step 7 --> complete payment (assertion)
        FC.generate_code();
        FC.assertion_fawry();
    }
    //@Test
//    void TC_06(){
//        // this case check thing after payment so we can not execute that
//        // step 1 --> open courses page (Hover and click "all courses")
//        PHL.hover();
//        PHL.click_allCourses();
//        // step 2 --> filter courses to be paid
//        PC.filter_paid();
//        //step 3&4 --> choose "Business Development Management " & click Enroll
//        PC.Enroll_paid();
//        // step 5 --> proceed to payment
//        PP.click_continue();
//        // step 6 --> Enter payment details
//        PP.chose_fawry();
//        PP.click_proceed();
//        // step 7 --> complete payment (assertion)
//        FC.generate_code();
//        // expected here that i complete payment then navigate to my courses
//        MC.navigate_Dashboard();
//        // check the existance of that course there
//    }
    @Test
    void TC_07(){
        // step 1 --> open courses page (Hover and click "all courses")
        PHL.hover();
        PHL.click_allCourses();
        // step 2 --> filter courses to be paid
        PC.filter_paid();
        //step 3&4 --> choose "Business Development Management " & click Enroll
        PC.Enroll_paid();
        // step 5 --> proceed to payment  (Visa)
        PP.click_continue();
        // step 6 --> Enter payment details    (is it essential to do all cases here ??????
        PP.chose_Card();
        PP.click_proceed();
        Cc.Enter_CardNo("1111111111111111");
        Cc.Enter_Name("zeinab");
        Cc.Enter_EX_month("09");
        Cc.Enter_Ex_year("26");
        Cc.Enter_cvv("111");
        // step 7 --> complete payment
        Cc.Click_submit();
        Cc.assertion_error();
    }
    //Ensure the paid course does not  appears in the user's dashboard after invalid payment.
    @Test
    void TC_08(){
        // step 1 --> open courses page (Hover and click "all courses")
        PHL.hover();
        PHL.click_allCourses();
        // step 2 --> filter courses to be paid
        PC.filter_paid();
        //step 3&4 --> choose "Business Development Management " & click Enroll
        PC.Enroll_paid();
        // step 5 --> proceed to payment  (Visa)
        PP.click_continue();
        // step 6 --> Enter payment details    (is it essential to do all cases here ??????
        PP.chose_Card();
        PP.click_proceed();
        Cc.Enter_CardNo("1111111111111111");
        Cc.Enter_Name("zeinab");
        Cc.Enter_EX_month("09");
        Cc.Enter_Ex_year("26");
        Cc.Enter_cvv("111");
        // step 7 --> complete payment
        Cc.Click_submit();
        Cc.assertion_error();
        // step 8 -->check user dashboard
        MC.navigate_Dashboard();
        MC.assertion_paid_false();

    }
    //Attempt to enroll in an already enrolled course
    @Test
    void TC_09() {
        // preReq
        // at least one enrolled course
        PHL.hover();
        PHL.click_allCourses();
        PC.filter_free();
        PC.Enroll_free();
        // step 1 --> open courses page (navigate to "all courses")
        PHL.navigate_home();
        PHL.hover();
        PHL.click_allCourses();
        // step 2 --> choose  any free enrolled course
        // filter courses to be free
        PC.filter_free();
        //step 3 --> choose any enrolled course & click Enroll
        PC.Enroll_free();
        // step 4 --> check behavior
        CD.assert_duplicate_prevention();

    }

    @AfterMethod
    void close() throws InterruptedException{
        Thread.sleep(2000);
        driver.quit();
    }
}
