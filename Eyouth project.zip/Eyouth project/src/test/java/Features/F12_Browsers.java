package Features;

import Pages.*;
import Pages.P01_Home;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class F12_Browsers {
    WebDriver driver;
    P01_Home PH;

    public void setup(int browserChoice)
    {
        switch (browserChoice) {
            case 0:
                driver = new ChromeDriver();
                break;
            case 1:
                driver = new FirefoxDriver();
                break;
            case 2:
                driver = new EdgeDriver();
                break;
            default:
                throw new IllegalArgumentException("Invalid browser choice: " + browserChoice);
        }
        PH=new P01_Home(driver);
    }

    @Test
    public void TC_1 ()
    {
        setup(0); // Chrome
        driver.get("https://eyouthlearning.com/");
        PH.AssertPass();
        System.out.println("Test executed on Chrome.");
    }

    @Test
    public void TC_2 ()
    {
        setup(1); // Firefox
        driver.get("https://eyouthlearning.com/");
        PH.AssertPass();
        System.out.println("Test executed on Firefox.");
    }

    @Test
    public void TC_4 ()
    {
        setup(2); // Edge
        driver.get("https://eyouthlearning.com/");
        PH.AssertPass();
        System.out.println("Test executed on Edge.");
    }

    @AfterMethod
    public void close() throws InterruptedException {
        Thread.sleep(5000);
        if (driver != null) {
            driver.quit();
        }
    }
}