package Features;

import Pages.*;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class F11_AppDownloadButton {

    ChromeDriver driver;
    P01_Home PH;
    P02_Login PL;
    P03_Home_logged_User PHL;
    P04_all_courses PC;
    P09_Course_Details CD;
    P06_Payment PP;


    @BeforeMethod
    void setUp() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        PH=new P01_Home(driver);
        PL=new P02_Login(driver);
        PHL=new P03_Home_logged_User(driver);
        PC= new P04_all_courses(driver);
        CD= new P09_Course_Details(driver);
        PP= new P06_Payment(driver);

        //  open Eyouth website
        driver.get("https://eyouthlearning.com/");

    }
    //Verify that download button is visible on the website.
    @Test
    void TC_1(){
        // attempt user the home page.
        PH.assert_home_page();
        //check if the  "mobile image button" is present  & assertion
        PH.check_download_button();
    }
    @Test
    //Verify that both Google Play and App Store buttons are visible on the website.
    void TC_2(){
        // attempt user the home page.
        PH.assert_home_page();
        //hover on "mobile image button"
        PH.check_download_button();
        PH.hover_download_btn();
        //Check if the Google Play button are present.
        PH.assert_googleIcon();
        // User Check if the App Store button are present.
        PH.assert_appleIcon();
    }
    // TC_03 to TC_08 we cannot execute here because they should open on phone either android or iphone
    //Verify that main download button have a hover effect indicating interactivity.
    @Test
    void TC_9(){

        // attempt user the home page.
        PH.assert_home_page();
        //User Hover over the "mobile Download image" button.
        PH.hover_download_btn();
        PH.assert_hover();

    }
    @AfterMethod
    void close() throws InterruptedException{
        Thread.sleep(2000);
        driver.quit();
    }
}
