package Features;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Pages.*;

public class F07_FawryPaymentTests {

	protected ChromeDriver driver = new ChromeDriver();
	P06_Payment PP = new P06_Payment(driver);
	P07_fawry_code PF=new P07_fawry_code(driver);
	P01_Home PH=new P01_Home(driver);
	P02_Login PL= new P02_Login(driver);
	 P04_all_courses PAC=new P04_all_courses(driver);
	 P09_Course_Details CD=new P09_Course_Details(driver);
	P03_Home_logged_User PHL =new P03_Home_logged_User(driver);


	@BeforeTest
	public void openBrowser() {
		driver.manage().window().maximize();
		driver.get("https://eyouthlearning.com/");

		// preRequest
		// 1--> change language , enter click immediately
		PH.click_dropdown();
		PH.send_input("English");

		// 2--> login
		PH.click_loginBtn();
		PL.Enter_userName("zeinab7");
		PL.Enter_password("88888888");
		PL.Click_Signin();
		PL.assert_login();
		//before running the tests you need to add some courses to your cart
		PHL.hover();
		PHL.click_allCourses();
		PAC.filter_paid();
		PAC.clickOn_Paidcourse(0);
		CD.assert_current_url();
		CD.assert_add2Cart('p',true);
	}

///TC01_Payment. User check that can proceed to the checkout page.
	@Test (groups = "fawry")
	public void TC_1() throws InterruptedException {
		Thread.sleep(3000);
		PH.openCart();
		Thread.sleep(3000);
		//User Check if payment gateway is displayed
		PP.check_continue();
		//Click the “continue” button
		PP.click_continue();
		// assertion
		PP.check_fawryCodeCB();
		PP.check_creditCardCB();

	}
	// TC02_Payment. User Verify that the "Proceed" Button is Enabled Only After Selecting a Payment Method
	@Test(groups = "fawry")
	public void TC_2() throws InterruptedException {
		Thread.sleep(3000);
		PH.openCart();
		Thread.sleep(3000);
		//User Check if payment gateway is displayed
		PP.check_continue();
		//Click the “continue” button
		PP.click_continue();
		//User Do not select any payment method.
		// assertion  (proceed button is disabled
		PP.check_proceed();

	}
	//TC03_Payment. User check Payment using Fawrey Method
	@Test
	public void TC_3() throws InterruptedException {
		PH.openCart();
		PP.check_continue();
		PP.click_continue();
		PP.chose_fawry();
		PP.click_proceed();

		PF.assert_fawry_img_displayed();
	}
	//TC04_Payment. User generate a fawry reference code using  phone number
	@Test
	public void TC_4(){
		// step 1
		PH.openCart();
		PP.check_continue();
		PP.click_continue();
		PP.chose_fawry();
		PP.click_proceed();
		// step 2
		PF.generate_code();
		PF.assertion_fawry();
	}
//	@Test
//	public void TC_5(){
//		// signup with non exist phone number
//	}


	@AfterTest
	public void closeBrowser() {
		driver.quit();
	}

}
