package Features;

import Pages.*;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.*;

import java.time.Duration;

public class F07_CreditCardPaymentTests {

	//before running the tests you need to add some courses to your car
    ChromeDriver driver;
    P06_Payment PP ;
	P01_Home PH;
	P02_Login PL;
	P08_Credit_card PC;
    P03_Home_logged_User PHL;
    P04_all_courses PAC;
    P09_Course_Details CD;
	@DataProvider
	public Object[][] InvalidCardData(){
		Object[][] data = new Object[8][6];
        data[0] = new Object[]{"4223303285041639", "Fatma Aboul Fotouh", "05", "20", "557", 1};
        data[1] = new Object[]{"4223303285041639", "Fatma Aboul Fotouh", "05", "29", "123", 2};
        data[2] = new Object[]{"4223303285041639", "Fatma Aboul Fotouh", "05", "29", "12", 3};
        data[3] = new Object[]{"4223303285041639", "Fatma Aboul Fotouh", "05", "29", "5==", 4};
        data[4] = new Object[]{"4223303285041751", "Fatma Aboul Fotouh", "05", "29", "557", 5};
        data[5] = new Object[]{"4223303285041639", "fatma Ahmed", "05", "29", "557", 6};
        data[6] = new Object[]{"4223303285041639", "Fatma Aboul85# 562", "05", "29", "557", 7};
        data[7] = new Object[]{"", "", "", "", "", 8};
		return data;
	}
	@BeforeTest
	public void openBrowser() {

        driver=new ChromeDriver();
        PP = new P06_Payment(driver);
         PH=new P01_Home(driver);
         PL= new P02_Login(driver);
         PC=new P08_Credit_card(driver);
         PHL =new P03_Home_logged_User(driver);
         PAC=new P04_all_courses(driver);
         CD=new P09_Course_Details(driver);
		driver.manage().window().maximize();
		driver.get("https://eyouthlearning.com/");

		// preRequest
		// 1--> change language , enter click immediately
		PH.click_dropdown();
		PH.send_input("English");

		// 2--> login
		PH.click_loginBtn();
		PL.Enter_userName("zeinab7");
		PL.Enter_password("88888888");
		PL.Click_Signin();
		PL.assert_login();

        // add at least one course
        PHL.hover();
        PHL.click_allCourses();
        PAC.filter_paid();
        PAC.clickOn_Paidcourse(0);
        CD.assert_current_url();
        CD.assert_add2Cart('p',true);

    }
    //TC07_Payment. user check Payment using Credit Card Method
	@Test (priority = 4 , groups = "credit card")
	public void creditCardIsAccessible() throws InterruptedException {
		Thread.sleep(3000);
		PH.openCart();
		Thread.sleep(3000);
        PP.check_continue();
		PP.click_continue();
		PP.chose_Card();
		PP.click_proceed();

		PC.check_continue(false);
		PC.check_goBack();
	}

	@Test (priority = 5 , groups = "credit card" , dataProvider = "InvalidCardData")
	public void InvalidCreditCard(String cardNumber , String name , String month , String year , String cvv,int key){
		PH.openCart();
		PP.click_continue();
		PP.chose_Card();
		PP.click_proceed();
		PC.assert_credit_url();
		// Fill invalid data and assert error
		PC.Enter_CardNo(cardNumber);
		PC.Enter_Name(name);
		PC.Enter_EX_month(month);
		PC.Enter_Ex_year(year);
		PC.Enter_cvv(cvv);
		PC.Click_submit();

		switch (key) {
			case 1:
                //TC10_Payment. User Check Payment with an Expired Card
				Assert.assertTrue(driver.findElement(By.xpath("//small[text()=\"اقل قيمة 25\"]")).isDisplayed());
				break;

			case 2:

                //TC11_Payment. User Check Payment with an Incorrect CVV (does not match the correct cvv)
                PC.assertion_failed();
				break;

			case 3:
                //TC12_Payment. User Check Payment with an Incorrect CVV (shorter than 3 digits)
                Assert.assertTrue(driver.findElement(By.xpath("//small[text()=\"3 أرقام فقط\"]")).isDisplayed());
                break;

			case 4:
                //TC13_Payment. User Check Payment with Entering a CVV with Alphabets or Special Characters
                PC.assertion_failed();
                break;

			case 5:
                //TC14_Payment. User Check Payment an Invalid Card Number ( does not match the card number on the card)
                //Assert.assertTrue(driver.findElement(By.xpath("//small[text()=\"Please make sure that card number is valid and try again\"]")).isDisplayed());
                Assert.assertTrue(driver.getCurrentUrl().equals("https://apps.experience.eyouthlearning.com/payment/fawry-card"));
                break;
			case 6:
                //TC15_Payment. User Check Payment with Entering a Different Name Than the Cardholder's Name
                PC.assertion_failed();
                break;

			case 7:
                //TC16_Payment. User Check Payment with Entering Numbers or Special Characters in the Cardholder Name Field
                PC.assertion_failed();
				break;

			case 8:
				//TC17_Payment. User Check Payment Without Entering Any Card Details
                Assert.assertTrue(driver.findElement(By.xpath("//small[text()=\"رمز الحماية مطلوب\"]")).isDisplayed());
                break;
		}
		PC.clear_card_data();
	}

    //TC08_Payment. User Check Payment with a Valid Credit Card
	@Test (priority = 6 , groups = "credit card")
	public void validCreditCard() throws InterruptedException
	{
		PH.openCart();
		Thread.sleep(3000);
		PP.click_continue();
		PP.chose_Card();
		PP.click_proceed();
        // Fill valid data and submit
		PC.Enter_CardNo("4223303285041639");
		PC.Enter_Name("Fatma Aboul Fotouh");
		PC.Enter_EX_month("05");
		PC.Enter_Ex_year("29");
		PC.Enter_cvv("557");
		PC.Click_submit();
        PC.assertion_success(false,"0");

	}
	///TC18_Payment. User Check Payment with a Valid Credit Card and Entering Wrong OTP code
    @Test (priority = 6 , groups = "credit card")
    public void invalid_otp() throws InterruptedException
    {
        PH.openCart();
        Thread.sleep(3000);
        PP.click_continue();
        PP.chose_Card();
        PP.click_proceed();
        // Fill valid data and submit
        PC.Enter_CardNo("4223303285041639");
        PC.Enter_Name("Fatma Aboul Fotouh");
        PC.Enter_EX_month("05");
        PC.Enter_Ex_year("29");
        PC.Enter_cvv("557");
        PC.Click_submit();
        PC.assertion_success(true,"1258");



    }
	@AfterTest
	void tearDown() throws InterruptedException {
		Thread.sleep(2000);
		driver.quit();
	}
}
