package Features;

import Pages.Pass_Reset.P01_Pass_Reset;
import Pages.Pass_Reset.P02_Assert_Reset;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class F03_Pass_Reset {

    ChromeDriver driver;
    P01_Pass_Reset PR;
    P02_Assert_Reset AR;

    @BeforeMethod
    void setup()
    {
        driver = new ChromeDriver();
        driver.get("https://eyouthlearning.com/signin?redirect=/");
        PR = new P01_Pass_Reset(driver);
        AR = new P02_Assert_Reset(driver);
    }

    @Test
    void TC_02 ()
    {
        PR.Click_ResetPassword();
        PR.EnterEmail("ahmed123@gmail.com");
        PR.Click_GetPassword();
        AR.Assert_NSent();
    }

    @Test
    void TC_03 ()
    {
        PR.Click_ResetPassword();
        PR.EnterEmail("ahmed123");
        PR.Click_GetPassword();
        AR.Assert_NSent();
    }

    @AfterMethod
    void close () throws InterruptedException {
        Thread.sleep(2000);
        driver.quit();
    }
}
