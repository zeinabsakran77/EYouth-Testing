package Features;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.awt.*;
import java.time.Duration;

public class F04_Course_Browsing {
    ChromeDriver driver;

    @BeforeMethod
    void setup() {
        this.driver = new ChromeDriver();
        //user opens main page (URL)
        this.driver.get("https://eyouthlearning.com/");
    }

    @Test
    void TC_search1() throws AWTException, InterruptedException {
        //user enters the course name in the search bar

        // Create a wait object
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        // 1. Find the search input by ID and enter text
        WebElement searchInput = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("highlights-demo")));
        searchInput.sendKeys("Data Analysis");

        Thread.sleep(3000);

        // 3. Press arrow down to select the first suggestion, then Enter
        searchInput.sendKeys(Keys.ARROW_DOWN);
        // 4. Click the search button
        searchInput.sendKeys(Keys.ENTER);

        boolean y = wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("courseDetails_courseTitle__tmIRd"))).isDisplayed();
        Assert.assertEquals(y, true, "assertion pass");

    }

    @Test
    void TC_search2() throws InterruptedException {
        // Create a wait object
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
       // Test user can not search for courses by entering invalid course name
        //user enters invalid course name in the search bar
        WebElement searchInput = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("highlights-demo")));
        searchInput.sendKeys("Commercial Law");

        Thread.sleep(3000);

        // 3. Press arrow down to select the first suggestion, then Enter
        searchInput.sendKeys(Keys.ARROW_DOWN);
        // 4. Click the search button
        searchInput.sendKeys(Keys.ENTER);
        //Assert.assertTrue(driver.getCurrentUrl().equals("https://eyouthlearning.com/"));
        boolean y =driver.getCurrentUrl().equals("https://eyouthlearning.com/");
        Assert.assertEquals(y, true, "assertion pass");
    }

    @Test
    void TC_search3() throws InterruptedException {
        // Create a wait object
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
       // Test user can not search for courses by entering invalid course name
       // user enters numbers in the search bar
        WebElement searchInput = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("highlights-demo")));
        searchInput.sendKeys("555");

        Thread.sleep(3000);

        boolean y =driver.getCurrentUrl().equals("https://eyouthlearning.com/");
        Assert.assertEquals(y, true, "assertion pass");

    }

    @Test
    void TC_search4() throws InterruptedException {
        // Create a wait object
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
       // Test user can not search for courses by entering invalid course name
       //user enters special characters in the search bar
        WebElement searchInput = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("highlights-demo")));
        searchInput.sendKeys("#%");

        Thread.sleep(3000);

        // 3. Press arrow down to select the first suggestion, then Enter
        searchInput.sendKeys(Keys.ARROW_DOWN);
        // 4. Click the search button
        searchInput.sendKeys(Keys.ENTER);

        boolean y =driver.getCurrentUrl().equals("https://eyouthlearning.com/");
        Assert.assertEquals(y, true, "assertion pass");
    }

    @Test
    void TC_search5() throws InterruptedException {
        // Create a wait object
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
       // Test user can not search for courses by entering invalid course name
     //user doesn't enter anything in the search bar
        WebElement searchInput = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("highlights-demo")));
        searchInput.sendKeys(" ");

        Thread.sleep(3000);

        // 3. Press arrow down to select the first suggestion, then Enter
        searchInput.sendKeys(Keys.ARROW_DOWN);
        // 4. Click the search button
        searchInput.sendKeys(Keys.ENTER);
        boolean y =driver.getCurrentUrl().equals("https://eyouthlearning.com/");
        Assert.assertEquals(y, true, "assertion pass");

    }


    @Test
    void TC_search6() throws InterruptedException {

        // Create a wait object
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
       // Test user can not search for courses by entering invalid course name
        // user doesn't enter anything in the search bar
        WebElement searchInput = wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("a[href=\"/all-courses\"]")));
        Actions Act = new Actions(this.driver);
        Act.moveToElement(this.driver.findElement(By.cssSelector("a[href=\"/all-courses\"]"))).perform();


        Thread.sleep(3000);
        // 3. Press arrow down to select the first suggestion, then Enter
        searchInput.sendKeys(Keys.ARROW_DOWN);

        searchInput.sendKeys(Keys.ENTER);
        // 4. select specific one
        WebElement element=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//label[@for=\"banking\"]")));
        element.click();

        boolean y=driver.getCurrentUrl().equals("https://eyouthlearning.com/all-courses?page=1&org=banking");
        Assert.assertEquals(y, true, "assertion pass");
    }

    @Test
    void TC_search7() throws InterruptedException{
        // Create a wait object
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        //Test user can browse courses and apply one filter by Delivery method
        WebElement searchInput = wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("a[href=\"/all-courses\"]")));
        Actions Act = new Actions(this.driver);
        Act.moveToElement(this.driver.findElement(By.cssSelector("a[href=\"/all-courses\"]"))).perform();


        Thread.sleep(3000);
        // 3. Press arrow down to select the first suggestion, then Enter
        searchInput.sendKeys(Keys.ARROW_DOWN);

        searchInput.sendKeys(Keys.ENTER);

        // 4. select "مدفوع"
        WebElement element=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//label[@for=\"Paid\"]")));
        element.click();
        boolean y=driver.getCurrentUrl().equals("https://eyouthlearning.com/all-courses?page=1&paid=true");
        Assert.assertEquals(y, true, "assertion pass");
    }

    @Test
    void TC_search8() throws InterruptedException{
        // Create a wait object
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        //Test user can browse courses and apply one filter by Delivery method
        WebElement searchInput = wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("a[href=\"/all-courses\"]")));
        Actions Act = new Actions(this.driver);
        Act.moveToElement(this.driver.findElement(By.cssSelector("a[href=\"/all-courses\"]"))).perform();


        Thread.sleep(3000);
        // 3. Press arrow down to select the first suggestion, then Enter
        searchInput.sendKeys(Keys.ARROW_DOWN);

        searchInput.sendKeys(Keys.ENTER);

        //select "برامج مسجلة تفاعلية"
        WebElement element=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id=\"panel2bh-content\"]/div/div/ul/li[1]/label")));
        element.click();

        boolean y=driver.getCurrentUrl().equals("https://eyouthlearning.com/all-courses?page=1&pacing=true");
        Assert.assertEquals(y, true, "assertion pass");

    }

    @Test
    void TC_search9() throws InterruptedException{
        // Create a wait object
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        //Test user can browse courses and apply one filter by Delivery method
        WebElement searchInput = wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("a[href=\"/all-courses\"]")));
        Actions Act = new Actions(this.driver);
        Act.moveToElement(this.driver.findElement(By.cssSelector("a[href=\"/all-courses\"]"))).perform();


        Thread.sleep(3000);
        // 3. Press arrow down to select the first suggestion, then Enter
        searchInput.sendKeys(Keys.ARROW_DOWN);

        searchInput.sendKeys(Keys.ENTER);

        //select "الخدمات المصرفية"
        WebElement element=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//label[@for=\"banking\"]")));
        element.click();
        //select "مدفوع"
        WebElement element2=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//label[@for=\"Paid\"]")));
        element2.click();
        boolean y=driver.getCurrentUrl().equals("https://eyouthlearning.com/all-courses?page=1&org=banking&paid=true");
        Assert.assertEquals(y, true, "assertion pass");

    }


    @Test
    void TC_search10() throws InterruptedException{
        // Create a wait object
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        //Test user can browse courses and apply one filter by Delivery method
        WebElement searchInput = wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("a[href=\"/all-courses\"]")));
        Actions Act = new Actions(this.driver);
        Act.moveToElement(this.driver.findElement(By.cssSelector("a[href=\"/all-courses\"]"))).perform();


        Thread.sleep(3000);
        // 3. Press arrow down to select the first suggestion, then Enter
        searchInput.sendKeys(Keys.ARROW_DOWN);

        searchInput.sendKeys(Keys.ENTER);
        //select "الخدمات المصرفية"
        WebElement element1=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//label[@for=\"banking\"]")));
        element1.click();
        //select "مدفوع"
        WebElement element2=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//label[@for=\"Paid\"]")));
        element2.click();
        //select "برامج مسجلة تفاعلية"
        WebElement element3=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//label[@for=\"No_Pace\"]")));
        element3.click();
        Thread.sleep(1000);
        boolean y =driver.findElement(By.xpath("//*[@id=\"coursesbody\"]/div/h2")).isDisplayed();
        Assert.assertEquals(y, true, "assertion pass");

    }

    @Test
    void TC_search11() throws AWTException, InterruptedException {
        // Create a wait object
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
       // Test user can not search for courses by entering invalid course name
     //user doesn't enter anything in the search bar
        WebElement searchInput = wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("a[href=\"/all-courses\"]")));
        Actions Act = new Actions(this.driver);
        Act.moveToElement(this.driver.findElement(By.cssSelector("a[href=\"/all-courses\"]"))).perform();


        Thread.sleep(3000);
        // 3. Press arrow down to select the first suggestion, then Enter
        searchInput.sendKeys(Keys.ARROW_DOWN);

        searchInput.sendKeys(Keys.ENTER);
        // 4. select specific one
        WebElement element=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//label[@for=\"banking\"]")));
        element.click();
        boolean y =wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("gap-3"))).isDisplayed();
        Assert.assertEquals(y, true, "assertion pass");
    }

    @Test
    void TC_search12() throws AWTException, InterruptedException {
        //user enters the course name in the search bar

        // Create a wait object
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        // 1. Find the search input by ID and enter text
        WebElement searchInput = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("highlights-demo")));
        searchInput.sendKeys("Data Analysis");

        Thread.sleep(3000);

        // 3. Press arrow down to select the first suggestion, then Enter
        searchInput.sendKeys(Keys.ARROW_DOWN);
        // 4. Click the search button
        searchInput.sendKeys(Keys.ENTER);
        //open page of details
        boolean y=driver.getCurrentUrl().equals("https://eyouthlearning.com/details/course-v1:Business_and_Management+DALXBR32024+DAHBYRE2024");
        Assert.assertEquals(y, true, "assertion pass");

    }

}