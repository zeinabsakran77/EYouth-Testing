package Features;

import Pages.*;
import Pages.P02_Login;
import Pages.P03_Home_logged_User;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class F02_Login {

    ChromeDriver driver;
    P02_Login PL;
    P03_Home_logged_User PHL;

    @BeforeMethod
    void setup()
    {
        driver = new ChromeDriver();
        driver.get("https://eyouthlearning.com/signin?redirect=/");
        PL=new P02_Login(driver);
        PHL=new P03_Home_logged_User(driver);
    }

    // Positive scenarios

    @Test
    void TC_02 ()  // Wrong Password + valid email
    {
        PL.Enter_userName("hana.yta.2005@gmail.com");
        PL.Enter_password("Hana218Y");
        PL.ClickLogin();
        PHL.AssertPass();
    }

    @Test
    void TC_03 ()   // correct Password + correct username
    {
        PL.Enter_userName("HanaYassin");
        PL.Enter_password("Hana218Y");
        PL.ClickLogin();
        PHL.AssertPass();
    }

    // Negative scenarios
    @Test
    void TC_04 ()   // Wrong Password + valid email
    {
        PL.Enter_userName("hana.yta.2005@gmail.com");
        PL.Enter_password("Hana123");
        PL.ClickLogin();
        PHL.AssertFail();
    }

    @Test
    void TC_05 ()   //  wrong email (wrong format) + correct Password
    {
        PL.Enter_userName("hana.yta.2005");
        PL.Enter_password("Hana218Y");
        PL.ClickLogin();
        PHL.AssertFail();
    }

    @Test
    void TC_06 ()   // wrong email (wrong format) + wrong Password
    {
        PL.Enter_userName("hana.yta.2005");
        PL.Enter_password("Hana123");
        PL.ClickLogin();
        PHL.AssertFail();
    }

    @Test
    void TC_07 ()   // invalid email (not registered) + correct  Password
    {
        PL.Enter_userName("sandra.5544@gamil.com");
        PL.Enter_password("Hana218Y");
        PL.ClickLogin();
        PHL.AssertFail();
    }

    @Test
    void TC_08 ()   // invalid email (not registered) + wrong  Password
    {
        PL.Enter_userName("sandra.5544@gamil.com");
        PL.Enter_password("Hana123");
        PL.ClickLogin();
        PHL.AssertFail();
    }

    @Test
    void TC_09 ()   // correct username + wrong password
    {
        PL.Enter_userName("HanaYassin");
        PL.Enter_password("Hana123");
        PL.ClickLogin();
        PHL.AssertFail();
    }

    @Test
    void TC_10 ()   //  wrong username + correct password
    {
        PL.Enter_userName("Hanaa Yassin ");
        PL.Enter_password("Hana218Y");
        PL.ClickLogin();
        PHL.AssertFail();
    }

    @Test
    void TC_11 ()   //  wrong username + wrong password
    {
        PL.Enter_userName("Hanaa Yassin");
        PL.Enter_password("Hana123");
        PL.ClickLogin();
        PHL.AssertFail();
    }

    @Test
    void TC_12 ()   //  valid email + no password
    {
        PL.Enter_userName("hana.yta.2005@gmail.com");

        PL.ClickLogin();
        PHL.AssertFail();
    }

    @Test
    void TC_13 ()   //  correct username + no password
    {
        PL.Enter_userName("HanaYassin");
        PL.ClickLogin();
        PHL.AssertFail();
    }

    @Test
    void TC_14 ()   //  no email or username + correct password
    {
        PL.Enter_password("Hana218Y");
        PL.ClickLogin();
        PHL.AssertFail();
    }

    @Test
    void TC_15 ()   //   without enter email or username and password
    {
        PL.ClickLogin();
        PHL.AssertFail();
    }

    @AfterMethod
    void close () throws InterruptedException {
        Thread.sleep(2000);
        driver.quit();
    }

}
