package Features;

import Pages.*;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class F01_Register {
    ChromeDriver driver;
    P05_C_Register MP;
    P06_Register RP;
    P07_Assert_Register AR;
    P01_Home PH;

    @BeforeMethod
    void setup() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        MP = new P05_C_Register(driver);
        RP = new P06_Register(driver);
        AR = new P07_Assert_Register(driver);
        PH= new P01_Home(driver);
        driver.get("https://eyouthlearning.com/");

        // preRequest
        // 1--> change language , enter click immediately
        PH.click_dropdown();
        PH.send_input("English");
        driver.navigate().to("https://eyouthlearning.com/signup?redirect=https://studio.eyouthlearning.com/home/");
        driver.manage().window().maximize();
    }

    @Test
    void TC_01() {
        RP.enterName("Enas Abdelqader");
        RP.enterUsername("Enas23Abdelqader");
        RP.selectCountry("Egypt");
        RP.selectGender("Female");
        RP.selectGovernment("Cairo");
        RP.enterEmail("enooabdeltwab67@gmail.com");
        RP.enterPhone("01146967346");
        RP.enterPassword("Q7DG7@pzQ76eWc");
        RP.enterConfirmPassword("Q7DG7@pzQ76eWc");
        RP.acceptTerms();
        RP.clickRegisterButton();
    }
    @Test
    void TC_03() {
        RP.enterName("Enas123$$Abdelqader");
        RP.enterUsername("Enas23Abdelqader");
        RP.selectCountry("Egypt");
        RP.selectGender("Female");
        RP.selectGovernment("Cairo");
        RP.enterEmail("test@example.com");
        RP.enterPhone("01146967346");
        RP.enterPassword("Q7DG7@pzQ76eWc");
        RP.enterConfirmPassword("Q7DG7@pzQ76eWc");
        RP.acceptTerms();
        RP.clickRegisterButton();
        AR.AssertNameError(1);
    }

    @Test
    void TC_04() {
        RP.enterUsername("Enas23Abdelqader");
        RP.selectCountry("Egypt");
        RP.selectGender("Female");
        RP.selectGovernment("Cairo");
        RP.enterEmail("test@example.com");
        RP.enterPhone("01146967346");
        RP.enterPassword("Q7DG7@pzQ76eWc");
        RP.enterConfirmPassword("Q7DG7@pzQ76eWc");
        RP.acceptTerms();
        RP.clickRegisterButton();
        AR.AssertNameError(0);
    }

    @Test
    void TC_05() {
        RP.enterName("Enas Abdelqader");
        RP.enterUsername("Enas Abdelqader");
        RP.selectCountry("Egypt");
        RP.selectGender("Female");
        RP.selectGovernment("Cairo");
        RP.enterEmail("test@example.com");
        RP.enterPhone("01146967346");
        RP.enterPassword("Q7DG7@pzQ76eWc");
        RP.enterConfirmPassword("Q7DG7@pzQ76eWc");
        RP.acceptTerms();
        RP.clickRegisterButton();
        AR.AssertUsernameError("The username should only contain letters and numbers, it should not contain spaces or signs");
    }

    @Test
    void TC_06() {
        RP.enterName("Enas Abdelqader");
        RP.selectCountry("Egypt");
        RP.selectGender("Female");
        RP.selectGovernment("Cairo");
        RP.enterEmail("test@example.com");
        RP.enterPhone("01146967346");
        RP.enterPassword("Q7DG7@pzQ76eWc");
        RP.enterConfirmPassword("Q7DG7@pzQ76eWc");
        RP.acceptTerms();
        RP.clickRegisterButton();
        AR.AssertUsernameError("User name required");
    }

    @Test
    void TC_07() {
        RP.enterName("Enas Abdelqader");
        RP.enterUsername("Enas23Abdelqader");
        RP.selectGender("Female");
        RP.selectGovernment("Cairo");
        RP.enterEmail("test@example.com");
        RP.enterPhone("01146967346");
        RP.enterPassword("Q7DG7@pzQ76eWc");
        RP.enterConfirmPassword("Q7DG7@pzQ76eWc");
        RP.acceptTerms();
        RP.clickRegisterButton();
        AR.AssertCountryError("الدولة مطلوبة");
    }

    @Test
    void TC_08() {
        RP.enterName("Enas Abdelqader");
        RP.enterUsername("Enas23Abdelqader");
        RP.selectCountry("Egypt");
        RP.selectGovernment("Cairo");
        RP.enterEmail("test@example.com");
        RP.enterPhone("01146967346");
        RP.enterPassword("Q7DG7@pzQ76eWc");
        RP.enterConfirmPassword("Q7DG7@pzQ76eWc");
        RP.acceptTerms();
        RP.clickRegisterButton();
        AR.AssertGenderError("النوع مطلوب");
    }

    @Test
    void TC_09() {
        RP.enterName("Enas Abdelqader");
        RP.enterUsername("Enas23Abdelqader");
        RP.selectCountry("Egypt");
        RP.selectGender("Female");
        RP.enterEmail("test@example.com");
        RP.enterPhone("01146967346");
        RP.enterPassword("Q7DG7@pzQ76eWc");
        RP.enterConfirmPassword("Q7DG7@pzQ76eWc");
        RP.acceptTerms();
        RP.clickRegisterButton();
        AR.AssertGovernmentError("المحافظة مطلوبة");
    }

    @Test
    void TC_10() {
        RP.enterName("Enas Abdelqader");
        RP.enterUsername("Enas23Abdelqader");
        RP.selectCountry("Egypt");
        RP.selectGender("Female");
        RP.selectGovernment("Cairo");
        RP.enterEmail("enooabdeltwab67gmail.com");
        RP.enterPhone("01146967346");
        RP.enterPassword("Q7DG7@pzQ76eWc");
        RP.enterConfirmPassword("Q7DG7@pzQ76eWc");
        RP.acceptTerms();
        RP.clickRegisterButton();
        AR.AssertEmailError("Enter a valid Email",0);
    }

    @Test
    void TC_11() {
        RP.enterName("Enas Abdelqader");
        RP.enterUsername("Enas23Abdelqader");
        RP.selectCountry("Egypt");
        RP.selectGender("Female");
        RP.selectGovernment("Cairo");
        RP.enterEmail("enooabdeltwab67@gmail.com");
        RP.enterPhone("01146967346");
        RP.enterPassword("Q7DG7@pzQ76eWc");
        RP.enterConfirmPassword("Q7DG7@pzQ76eWc");
        RP.acceptTerms();
        RP.clickRegisterButton();
        AR.AssertEmailError("duplicate-email",1);
    }

    @Test
    void TC_13() {
        RP.enterName("Enas Abdelqader");
        RP.enterUsername("Enas23Abdelqader");
        RP.selectCountry("Egypt");
        RP.selectGender("Female");
        RP.selectGovernment("Cairo");
        RP.enterPhone("01146967346");
        RP.enterPassword("Q7DG7@pzQ76eWc");
        RP.enterConfirmPassword("Q7DG7@pzQ76eWc");
        RP.acceptTerms();
        RP.clickRegisterButton();
        AR.AssertEmailError("Email is required",0);
    }

    @Test
    void TC_14() {
        RP.enterName("Enas Abdelqader");
        RP.enterUsername("Enas23Abdelqader");
        RP.selectCountry("Egypt");
        RP.selectGender("Female");
        RP.selectGovernment("Cairo");
        RP.enterEmail("test@example.com");
        RP.enterPhone("011469");
        RP.enterPassword("Q7DG7@pzQ76eWc");
        RP.enterConfirmPassword("Q7DG7@pzQ76eWc");
        RP.acceptTerms();
        RP.clickRegisterButton();
        AR.AssertPhoneError("Phone number is at least 7 digits");
    }

    @Test
    void TC_15() {
        RP.enterName("Enas Abdelqader");
        RP.enterUsername("Enas23Abdelqader");
        RP.selectCountry("Egypt");
        RP.selectGender("Female");
        RP.selectGovernment("Cairo");
        RP.enterEmail("test@example.com");
        RP.enterPhone("0114696734633354");
        RP.enterPassword("Q7DG7@pzQ76eWc");
        RP.enterConfirmPassword("Q7DG7@pzQ76eWc");
        RP.acceptTerms();
        RP.clickRegisterButton();
        AR.AssertPhoneError("Phone number no more than 15 digits");
    }

    @Test
    void TC_16() {
        RP.enterName("Enas Abdelqader");
        RP.enterUsername("Enas23Abdelqader");
        RP.selectCountry("Egypt");
        RP.selectGender("Female");
        RP.selectGovernment("Cairo");
        RP.enterEmail("test@example.com");
        RP.enterPassword("Q7DG7@pzQ76eWc");
        RP.enterConfirmPassword("Q7DG7@pzQ76eWc");
        RP.acceptTerms();
        RP.clickRegisterButton();
        AR.AssertPhoneError("Phone number is required");
    }

    @Test
    void TC_17() {
        RP.enterName("Enas Abdelqader");
        RP.enterUsername("Enas23Abdelqader");
        RP.selectCountry("Egypt");
        RP.selectGender("Female");
        RP.selectGovernment("Cairo");
        RP.enterEmail("test@example.com");
        RP.enterPhone("01145$$nvdkjnd");
        RP.enterPassword("Q7DG7@pzQ76eWc");
        RP.enterConfirmPassword("Q7DG7@pzQ76eWc");
        RP.acceptTerms();
        RP.clickRegisterButton();
        AR.AssertPhoneError("It must be a number");
    }

    @Test
    void TC_18() {
        RP.enterName("Enas Abdelqader");
        RP.enterUsername("Enas23Abdelqader");
        RP.selectCountry("Egypt");
        RP.selectGender("Female");
        RP.selectGovernment("Cairo");
        RP.enterEmail("test@example.com");
        RP.enterPhone("01146967346");
        RP.enterPassword("Q7D");
        RP.enterConfirmPassword("Q7D");
        RP.acceptTerms();
        RP.clickRegisterButton();
        AR.AssertPasswordError("Password minimum length is 8");
    }

    @Test
    void TC_19() {
        RP.enterName("Enas Abdelqader");
        RP.enterUsername("Enas23Abdelqader");
        RP.selectCountry("Egypt");
        RP.selectGender("Female");
        RP.selectGovernment("Cairo");
        RP.enterEmail("test@example.com");
        RP.enterPhone("01146967346");
        RP.enterPassword("12345678");
        RP.enterConfirmPassword("12345678");
        RP.acceptTerms();
        RP.clickRegisterButton();
        // May still pass but might show a warning
    }

    @Test
    void TC_20() {
        RP.enterName("Enas Abdelqader");
        RP.enterUsername("Enas23Abdelqader");
        RP.selectCountry("Egypt");
        RP.selectGender("Female");
        RP.selectGovernment("Cairo");
        RP.enterEmail("test@example.com");
        RP.enterPhone("01146967346");
        RP.enterConfirmPassword("Q7DG7@pzQ76eWc");
        RP.acceptTerms();
        RP.clickRegisterButton();
        AR.AssertPasswordError("Password required");
    }

    @Test
    void TC_21() {
        RP.enterName("Enas Abdelqader");
        RP.enterUsername("Enas23Abdelqader");
        RP.selectCountry("Egypt");
        RP.selectGender("Female");
        RP.selectGovernment("Cairo");
        RP.enterEmail("test@example.com");
        RP.enterPhone("01146967346");
        RP.enterPassword("Q7DG7@pzQ76eWc");
        RP.enterConfirmPassword("Q7DG7@pzQ7cW");
        RP.acceptTerms();
        RP.clickRegisterButton();
        AR.AssertConfirmPasswordError("Passwords must match");
    }

    @Test
    void TC_22() {
        RP.enterName("Enas Abdelqader");
        RP.enterUsername("Enas23Abdelqader");
        RP.selectCountry("Egypt");
        RP.selectGender("Female");
        RP.selectGovernment("Cairo");
        RP.enterEmail("test@example.com");
        RP.enterPhone("01146967346");
        RP.enterPassword("Q7DG7@pzQ76eWc");
        RP.acceptTerms();
        RP.clickRegisterButton();
        AR.AssertConfirmPasswordError("Password confirmation is required");
    }

    @Test
    void TC_23() {
        RP.enterName("Enas Abdelqader");
        RP.enterUsername("Enas23Abdelqader");
        RP.selectCountry("Egypt");
        RP.selectGender("Female");
        RP.selectGovernment("Cairo");
        RP.enterEmail("test@example.com");
        RP.enterPhone("01146967346");
        RP.enterPassword("Q7DG7@pzQ76eWc");
        RP.enterConfirmPassword("Q7DG7@pzQ76eWc");
        RP.clickRegisterButton();
        AR.AssertTermsError("Terms and conditions must be agreed");
    }

    @Test
    void TC_24() {
        RP.clickRegisterButton();
        AR.AssertNameError(0);
        AR.AssertUsernameError("User name required");
        //AR.AssertCountryError("The country is required");
        //AR.AssertGenderError("The gender is required");
        //AR.AssertGovernmentError("The government is required");
        AR.AssertEmailError("Email is required",0);
        AR.AssertPhoneError("Phone number is required");
        AR.AssertPasswordError("Password required");
        AR.AssertConfirmPasswordError("Password confirmation is required");
        AR.AssertTermsError("Terms and conditions must be agreed");
    }

    @AfterMethod
    void close() throws InterruptedException {
        Thread.sleep(2000);
        driver.quit();
    }
}
