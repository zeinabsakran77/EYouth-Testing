package Features;

import Pages.*;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.time.Duration;

public class F06_AddToCart {
    ChromeDriver driver;
    P01_Home PH;
    P02_Login PL;
    P03_Home_logged_User PHL;
    P04_all_courses PC;
    P09_Course_Details CD;
    P06_Payment PP;


    @BeforeMethod
    void setUp() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        PH=new P01_Home(driver);
        PL=new P02_Login(driver);
        PHL=new P03_Home_logged_User(driver);
        PC= new P04_all_courses(driver);
        CD= new P09_Course_Details(driver);
        PP= new P06_Payment(driver);

        driver.get("https://eyouthlearning.com/");

        // preRequest
        // 1--> change language , enter click immediately
        PH.click_dropdown();
        PH.send_input("English");

        // 2--> login
        PH.click_loginBtn();
        PL.Enter_userName("zeinab7");
        PL.Enter_password("88888888");
        PL.Click_Signin();
        PL.assert_login();
    }
    // this is a bug
    //Verify that users can add paid courses to the cart from the course listing page
    @Test
    void TC_01() {
        // step 1 --> open courses page (Hover and click "all courses")
        PHL.hover();
        PHL.click_allCourses();
        // step 2 --> filter courses to be paid
        PC.filter_paid();
        // step 3 --> check for icon "add to cart" for the chosen course "Business Development Management "
        PC.check_add2Cart_btn();

    }
    //Verify that users can add paid courses to the cart from the course details page
    @Test
    void TC_02(){
        // step 1 --> open courses page (Hover and click "all courses")
        PHL.hover();
        PHL.click_allCourses();
        // step 2 --> filter courses to be paid
        PC.filter_paid();
        // step 3 --> choose and click a specific  course
        PC.clickOn_Paidcourse(0);
        CD.assert_current_url();
        // step 4 -->  check if there is icon to add to cart
        CD.assert_add2Cart('p',false);
    }
    //check that Users can add free courses to the cart from the course details page
    @Test
    // this is a bug
    void TC_03(){
        // step 1 --> open courses page (Hover and click "all courses")
        PHL.hover();
        PHL.click_allCourses();
        // step 2 --> filter courses to be free
        PC.filter_free();
        // step 3 --> choose and click a specific  course
        PC.clickOn_Freecourse();
        CD.assert_current_url();
        // step 4 -->  check if there is icon to add to cart
        CD.assert_add2Cart('f',false);
    }
    //check that Users redirect to payment gateway after add paid courses to the cart from the course details page
    @Test
    void TC_04(){
        // step 1 --> open courses page (Hover and click "all courses")
        PHL.hover();
        PHL.click_allCourses();
        // step 2 --> filter courses to be paid
        PC.filter_paid();
        // step 3 --> choose and click a specific  course
        PC.clickOn_Paidcourse(0);
        CD.assert_current_url();
        // step 4 -->  check if there is icon to add to cart
        CD.assert_add2Cart('p',true);
        PP.assertion_redirect();

    }
    //Verify that the cart content updates when a course is added
    @Test
    void TC_05(){
        // preReq
        // remove elements in the cart if exist
        PHL.click_CartBtn();
        PP.check_btn_Delete();
        PP.assert_empty_cart();
        PHL.navigate_home();
        // step 1 --> open courses page (Hover and click "all courses")
        PHL.hover();
        PHL.click_allCourses();
        // step 2 --> filter courses to be paid & choose and click a specific  course
        PC.filter_paid();
        PC.clickOn_Paidcourse(0);
        CD.assert_current_url();
        // step 3 --> click add to cart
        CD.assert_add2Cart('p',true);
        // step 4 --> check number of courses in the cart
        PP.check_NoOf_Courses("1");
        // step 5--> choose another paid course
        PC.navigate_All_PaidCourses();
        PC.clickOn_Paidcourse(1);
        // step 6 --> Click "Add to Cart"
        CD.assert_add2Cart('p',true);
        // step 7 --> check number of courses in the cart
        PP.check_NoOf_Courses("2");
    }
    //Verify that duplicate courses cannot be added to the cart
    @Test
    void TC_06(){
        // remove elements in the cart if exist
        PHL.click_CartBtn();
        PP.check_btn_Delete();
        PP.assert_empty_cart();
        PHL.navigate_home();
        // step 1 --> open courses page (Hover and click "all courses")
        PHL.hover();
        PHL.click_allCourses();
        // step 2 --> filter courses to be paid & choose and click a specific  course
        PC.filter_paid();
        PC.clickOn_Paidcourse(0);
        CD.assert_current_url();
        // step 3 --> click add to cart
        CD.assert_add2Cart('p',true);
        // step 4 --> check number of courses in the cart
        PP.check_NoOf_Courses("1");
        // step 5--> choose the same paid course
        PC.navigate_All_PaidCourses();
        PC.clickOn_Paidcourse(0);
        // step 6 --> Click "Add to Cart"
        CD.assert_add2Cart('p',true);
        // step 7 --> check number of courses in the cart
        PP.check_NoOf_Courses("1");
    }
    //Check that users can view courses, and see the total price in the cart.
    @Test
    void TC_07(){
        // preReq
        // add at least one course
        PHL.hover();
        PHL.click_allCourses();
        PC.filter_paid();
        PC.clickOn_Paidcourse(0);
        CD.assert_current_url();
        CD.assert_add2Cart('p',true);
        PP.assertion_redirect();
        // another course
        PC.navigate_All_PaidCourses();
        PC.clickOn_Paidcourse(1);
        CD.assert_add2Cart('p',true);
        PP.assertion_redirect();
        // step 1 --> navigate to home page
        PHL.navigate_home();
        // step 2 -->  click icon of "add to cart"
       PHL.click_CartBtn();
        // step 3 --> Observe the contents
        PP.observe_course_contents();

    }
    //Verify that users can remove a course from the cart.
    @Test
    void TC_08(){
        // preReq
        // add at least one course
        PHL.hover();
        PHL.click_allCourses();
        PC.filter_paid();
        PC.clickOn_Paidcourse(0);
        CD.assert_current_url();
        CD.assert_add2Cart('p',true);

        // step 1 --> navigate to home page
        PHL.navigate_home();
        // step 2 -->  click icon of "add to cart"
        PHL.click_CartBtn();
        // step 3 --> click "delete" for course in cart
        PP.Delete_course();
        //assertion
        PP.assert_deletedCourse();


    }
    //Verify that users can proceed to checkout for paid courses
    @Test
    void TC_09(){
        //PreRequest
        // add at least one course
        PHL.hover();
        PHL.click_allCourses();
        PC.filter_paid();
        PC.clickOn_Paidcourse(0);
        CD.assert_current_url();
        CD.assert_add2Cart('p',true);
        PP.assertion_redirect();
        // step 1 --> navigate to home page
        PHL.navigate_home();
        // step 2 -->  click icon of "add to cart"
        PHL.click_CartBtn();
        // step 3 -->  click continue
        PP.click_continue();
        PP.assert_proceed_checkout();
    }

    //Verify that cart contents persist after logout and login
    @Test
    void TC_10(){
        // step 1 --> open courses page (Hover and click "all courses")
        PHL.hover();
        PHL.click_allCourses();
        // step 2 --> filter courses to be paid & choose and click a specific  course
        PC.filter_paid();
        PC.clickOn_Paidcourse(0);
        CD.assert_current_url();
        // step 3 --> click add to cart
        CD.assert_add2Cart('p',true);
        // step 4 -->  logout from the website
        PP.click_logout();
        // step 5 --> login again
        PH.click_loginBtn();
        PL.Enter_userName("zeinab7");
        PL.Enter_password("88888888");
        PL.Click_Signin();
        PL.assert_login();
        // step 6 --> open the cart
        PHL.click_CartBtn();
        PP.assert_ExistanceCourse();
    }
    //Verify system behavior when a user removes a course from the cart and refreshes
    @Test
    void TC_11(){
        //preRequest
        // ensure that there is at least one course
        PHL.hover();
        PHL.click_allCourses();
        PC.filter_paid();
        PC.clickOn_Paidcourse(0);
        CD.assert_current_url();
        CD.assert_add2Cart('p',true);
        // step 1 --> navigate to home page
        PHL.navigate_home();
        // step 2 --> click add to cart
        PHL.click_CartBtn();
        // step 3 --> click delete all btn
        PP.check_btn_Delete();
        //step 4 --> refresh
        driver.navigate().refresh();
        // assertion   cart still empty
        PP.assert_DeletionAll();


    }
    //Verify system behavior if a user refreshes the page during cart update
    @Test
    void TC_12(){
        // step 1 --> open courses page (Hover and click "all courses")
        PHL.hover();
        PHL.click_allCourses();
        // step 2 --> filter courses to be paid & choose and click a specific  course
        PC.filter_paid();
        PC.clickOn_Paidcourse(0);
        CD.assert_current_url();
        // step 3 --> click add to cart
        CD.assert_add2Cart('p',true);
        // step 4 --> refresh the page
        //driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        driver.navigate().refresh();
        // assertion open cart and check the existance of course
        PHL.click_CartBtn();
        PP.assert_ExistanceCourse();
    }
    //Verify that the cart icon updates dynamically when a course is added
    @Test
    void TC_13(){
        // preReq
        // remove elements in the cart if exist
        PHL.click_CartBtn();
        PP.check_btn_Delete();
        PP.assert_empty_cart();
        PHL.navigate_home();
        // step 1 --> open courses page (Hover and click "all courses")
        PHL.hover();
        PHL.click_allCourses();
        // step 2 --> filter courses to be paid & choose and click a specific  course
        PC.filter_paid();
        PC.clickOn_Paidcourse(0);
        CD.assert_current_url();
        // step 3 --> click add to cart
        CD.assert_add2Cart('p',true);
        // step 4 --> check number of courses in the cart
        PP.check_NoOf_Courses("1");
        // step 5--> choose another paid course
        PC.navigate_All_PaidCourses();
        PC.clickOn_Paidcourse(1);
        // step 6 --> Click "Add to Cart"
        CD.assert_add2Cart('p',true);
        // step 7 --> check number of courses in the cart
        PP.check_NoOf_Courses("2");
        // step 8 -->  delete the first course
        PP.Delete_course();
        PP.assert_deletedCourse();
       // step 9 --> check cart icon
        PP.check_NoOf_Courses("1");
    }
    @AfterMethod
    void close() throws InterruptedException{
        Thread.sleep(2000);
        driver.quit();
    }
}

