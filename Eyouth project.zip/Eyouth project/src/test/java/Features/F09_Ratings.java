package Features;

import Pages.*;
import Pages.Ratings.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class F09_Ratings {

    ChromeDriver driver;
    P01_LoginFirst LP;
    P02_GoToCourse CP;         // CP = Course Page
    P03_GetIntoCourse SC;      // SC = Specific course
    P04_AddReview AR;          // AR = ADD Review
    P05_Assertion AP;          // AP = Assertion Page The specific Course details
    P06_ChooseCourse CC;       // CC = Choose course without Login

    @BeforeMethod
    void setup()
    {
        driver = new ChromeDriver();
        driver.get("https://eyouthlearning.com/signin?redirect=/");
        LP = new P01_LoginFirst(driver);
        CP = new P02_GoToCourse(driver);
        SC = new P03_GetIntoCourse(driver);
        AR = new P04_AddReview(driver);
        AP = new P05_Assertion(driver);
        CC = new P06_ChooseCourse(driver);
    }
    @Test
    void TC_01 ()
    {
        LP.EnterUserName("HanaYassin");
        LP.EnterPassword("Hana218Y");
        LP.ClickLogin();
        CP.AssertPass();
        // CP.MyCourses();
        CP.OpenMyCourses();
        CP.MyCoursesLoc();
        SC.Add_ReviewLoc();
        AR.JustWait();
        AR.Add_Title("Just a Review For Test ");
        AR.Choose3Stars();
        AR.Add_Subject("Just For Test");
        AR.Click_Submit();
        AP.AssertReviewAdded();
    }
    @Test
    void TC_02 ()
    {
        LP.EnterUserName("HanaYassin");
        LP.EnterPassword("Hana218Y");
        LP.ClickLogin();
        CP.AssertPass();
        // CP.MyCourses();
        CP.OpenMyCourses();
        CP.MyCoursesLoc();
        SC.Add_ReviewLoc();
        AR.JustWait();
        AR.Add_Title("Just a Review For Test ");
        AR.Add_Subject("Just For Test");
        AR.Click_Submit();
        AP.AssertReviewAdded();
    }
    @Test
    void TC_03 ()
    {
        LP.EnterUserName("HanaYassin");
        LP.EnterPassword("Hana218Y");
        LP.ClickLogin();
        CP.AssertPass();
        // CP.MyCourses();
        CP.OpenMyCourses();
        CP.MyCoursesLoc();
        SC.Add_ReviewLoc();
        AR.JustWait();
        AR.Choose3Stars();
        AR.Add_Subject("Just For Test");
        AR.Click_Submit();
        AP.AssertReview_NAdded();
    }
    @Test
    void TC_04 ()
    {
        LP.EnterUserName("HanaYassin");
        LP.EnterPassword("Hana218Y");
        LP.ClickLogin();
        CP.AssertPass();
        // CP.MyCourses();
        CP.OpenMyCourses();
        CP.MyCoursesLoc();
        SC.Add_ReviewLoc();
        AR.JustWait();
        AR.Add_Title("Just a Review For Test ");
        AR.Choose3Stars();
        AR.Click_Submit();
        AP.AssertReview_NAdded();
    }
    @Test
    void TC_05 ()
    {
        LP.EnterUserName("HanaYassin");
        LP.EnterPassword("Hana218Y");
        LP.ClickLogin();
        CP.AssertPass();
        // CP.MyCourses();
        CP.OpenMyCourses();
        CP.MyCoursesLoc();
        SC.Add_ReviewLoc();
        AR.JustWait();
        AR.Choose2Stars();
        AR.Click_Submit();
        AP.AssertReview_NAdded();
    }
    @Test
    void TC_06 ()
    {
        LP.GoToHome();
        CP.assert_notlogged_user();
    }
    @Test
    void TC_07 ()
    {
        LP.EnterUserName("HanaYassin");
        LP.EnterPassword("Hana218Y");
        LP.ClickLogin();
        CP.AssertPass();
        // CP.MyCourses();
        CP.OpenMyCourses();
        CP.MyCoursesLoc();
        SC.Add_ReviewLoc();
        AR.JustWait();
        AR.Add_Title("Just a Review For Test ");
        AR.Choose4Stars();
        AR.Add_Subject("Just For Test! @#$%^&*()");
        AR.Click_Submit();
        AP.AssertReviewAdded();
    }
    @Test
    void TC_08 () throws InterruptedException     //More pages
    {
        LP.EnterUserName("HanaYassin");
        LP.EnterPassword("Hana218Y");
        LP.ClickLogin();
        CP.AssertPass();
        // CP.MyCourses();
        CP.OpenMyCourses();
        CP.MyCoursesLoc();
        SC.GoToCourse();
        AP.CheckNum1();
        SC.Add_ReviewLoc();
        AR.JustWait();
        AR.Add_Title("Just a Review For Test ");
        AR.Choose5Stars();
        AR.Add_Subject("Just For Test");
        AR.Click_Submit();
        AP.AssertReviewAdded();
        AP.CheckNum2();
    }
    @AfterMethod
    void close () throws InterruptedException {
        Thread.sleep(2000);
        driver.quit();
    }
}
